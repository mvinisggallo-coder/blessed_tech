﻿namespace sistemaBlessed
{
    partial class frm_equipamentoOs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pic_imageEquipa = new System.Windows.Forms.PictureBox();
            this.btnCarregarImagemEquipa = new System.Windows.Forms.Button();
            this.txtIdEquipa = new System.Windows.Forms.TextBox();
            this.txtNomeEquipa = new System.Windows.Forms.TextBox();
            this.txtCatEquipa = new System.Windows.Forms.TextBox();
            this.txtGarantiaEquipa = new System.Windows.Forms.TextBox();
            this.txtMarcaEquipa = new System.Windows.Forms.TextBox();
            this.txtmodeloEquipa = new System.Windows.Forms.TextBox();
            this.txtNumeroSerieEquipa = new System.Windows.Forms.TextBox();
            this.txtEstadoFisEquipa = new System.Windows.Forms.TextBox();
            this.txtSenhaSeFornecEquipa = new System.Windows.Forms.TextBox();
            this.btnCadastrarEquipa = new System.Windows.Forms.Button();
            this.btnBuscarEquipa = new System.Windows.Forms.Button();
            this.btnExcluirEquipa = new System.Windows.Forms.Button();
            this.btnAlterarEquipa = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbResponsavelEquipa = new System.Windows.Forms.ComboBox();
            this.txtCPF = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageEquipa)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(39, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(905, 69);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cadastro de Equipamentos para OS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(56, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 10;
            this.label10.Text = "ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(47, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "Nome do Equipamento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(47, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 24);
            this.label4.TabIndex = 13;
            this.label4.Text = "Categoria";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label5.Location = new System.Drawing.Point(270, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 24);
            this.label5.TabIndex = 14;
            this.label5.Text = "Garantia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label6.Location = new System.Drawing.Point(502, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 24);
            this.label6.TabIndex = 15;
            this.label6.Text = "Nome do Cliente";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(50, 331);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 24);
            this.label7.TabIndex = 16;
            this.label7.Text = "Marca";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(273, 331);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 24);
            this.label8.TabIndex = 17;
            this.label8.Text = "Modelo";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label9.Location = new System.Drawing.Point(49, 403);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 24);
            this.label9.TabIndex = 18;
            this.label9.Text = "Número de Série";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label11.Location = new System.Drawing.Point(273, 403);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 24);
            this.label11.TabIndex = 19;
            this.label11.Text = "Estado Físico";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label12.Location = new System.Drawing.Point(50, 467);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(184, 24);
            this.label12.TabIndex = 20;
            this.label12.Text = "Senha se Fornecida";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label13.Location = new System.Drawing.Point(662, 250);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(239, 24);
            this.label13.TabIndex = 21;
            this.label13.Text = "Imagem do Equipamento";
            // 
            // pic_imageEquipa
            // 
            this.pic_imageEquipa.Location = new System.Drawing.Point(631, 287);
            this.pic_imageEquipa.Name = "pic_imageEquipa";
            this.pic_imageEquipa.Size = new System.Drawing.Size(297, 233);
            this.pic_imageEquipa.TabIndex = 22;
            this.pic_imageEquipa.TabStop = false;
            // 
            // btnCarregarImagemEquipa
            // 
            this.btnCarregarImagemEquipa.Location = new System.Drawing.Point(720, 526);
            this.btnCarregarImagemEquipa.Name = "btnCarregarImagemEquipa";
            this.btnCarregarImagemEquipa.Size = new System.Drawing.Size(116, 23);
            this.btnCarregarImagemEquipa.TabIndex = 29;
            this.btnCarregarImagemEquipa.Text = "Carregar Imagem";
            this.btnCarregarImagemEquipa.UseVisualStyleBackColor = true;
            this.btnCarregarImagemEquipa.Click += new System.EventHandler(this.btnCarregarImagemEquipa_Click);
            // 
            // txtIdEquipa
            // 
            this.txtIdEquipa.Location = new System.Drawing.Point(84, 100);
            this.txtIdEquipa.Name = "txtIdEquipa";
            this.txtIdEquipa.Size = new System.Drawing.Size(100, 20);
            this.txtIdEquipa.TabIndex = 30;
//            this.txtIdEquipa.TextChanged += new System.EventHandler(this.txtIdEquipa_TextChanged);
            // 
            // txtNomeEquipa
            // 
            this.txtNomeEquipa.Location = new System.Drawing.Point(51, 219);
            this.txtNomeEquipa.Name = "txtNomeEquipa";
            this.txtNomeEquipa.Size = new System.Drawing.Size(387, 20);
            this.txtNomeEquipa.TabIndex = 32;
            // 
            // txtCatEquipa
            // 
            this.txtCatEquipa.Location = new System.Drawing.Point(51, 287);
            this.txtCatEquipa.Name = "txtCatEquipa";
            this.txtCatEquipa.Size = new System.Drawing.Size(173, 20);
            this.txtCatEquipa.TabIndex = 34;
            // 
            // txtGarantiaEquipa
            // 
            this.txtGarantiaEquipa.Location = new System.Drawing.Point(271, 287);
            this.txtGarantiaEquipa.Name = "txtGarantiaEquipa";
            this.txtGarantiaEquipa.Size = new System.Drawing.Size(140, 20);
            this.txtGarantiaEquipa.TabIndex = 35;
            // 
            // txtMarcaEquipa
            // 
            this.txtMarcaEquipa.Location = new System.Drawing.Point(51, 358);
            this.txtMarcaEquipa.Name = "txtMarcaEquipa";
            this.txtMarcaEquipa.Size = new System.Drawing.Size(173, 20);
            this.txtMarcaEquipa.TabIndex = 36;
            // 
            // txtmodeloEquipa
            // 
            this.txtmodeloEquipa.Location = new System.Drawing.Point(271, 358);
            this.txtmodeloEquipa.Name = "txtmodeloEquipa";
            this.txtmodeloEquipa.Size = new System.Drawing.Size(167, 20);
            this.txtmodeloEquipa.TabIndex = 37;
            // 
            // txtNumeroSerieEquipa
            // 
            this.txtNumeroSerieEquipa.Location = new System.Drawing.Point(51, 430);
            this.txtNumeroSerieEquipa.Name = "txtNumeroSerieEquipa";
            this.txtNumeroSerieEquipa.Size = new System.Drawing.Size(173, 20);
            this.txtNumeroSerieEquipa.TabIndex = 38;
            // 
            // txtEstadoFisEquipa
            // 
            this.txtEstadoFisEquipa.Location = new System.Drawing.Point(271, 430);
            this.txtEstadoFisEquipa.Name = "txtEstadoFisEquipa";
            this.txtEstadoFisEquipa.Size = new System.Drawing.Size(173, 20);
            this.txtEstadoFisEquipa.TabIndex = 39;
            // 
            // txtSenhaSeFornecEquipa
            // 
            this.txtSenhaSeFornecEquipa.Location = new System.Drawing.Point(240, 472);
            this.txtSenhaSeFornecEquipa.Name = "txtSenhaSeFornecEquipa";
            this.txtSenhaSeFornecEquipa.Size = new System.Drawing.Size(204, 20);
            this.txtSenhaSeFornecEquipa.TabIndex = 40;
            // 
            // btnCadastrarEquipa
            // 
            this.btnCadastrarEquipa.Location = new System.Drawing.Point(543, 567);
            this.btnCadastrarEquipa.Name = "btnCadastrarEquipa";
            this.btnCadastrarEquipa.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarEquipa.TabIndex = 44;
            this.btnCadastrarEquipa.Text = "Cadastrar";
            this.btnCadastrarEquipa.UseVisualStyleBackColor = true;
            this.btnCadastrarEquipa.Click += new System.EventHandler(this.btnCadastrarEquipa_Click_1);
            // 
            // btnBuscarEquipa
            // 
            this.btnBuscarEquipa.Location = new System.Drawing.Point(853, 567);
            this.btnBuscarEquipa.Name = "btnBuscarEquipa";
            this.btnBuscarEquipa.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarEquipa.TabIndex = 43;
            this.btnBuscarEquipa.Text = "Buscar";
            this.btnBuscarEquipa.UseVisualStyleBackColor = true;
            this.btnBuscarEquipa.Click += new System.EventHandler(this.btnBuscarEquipa_Click);
            // 
            // btnExcluirEquipa
            // 
            this.btnExcluirEquipa.Location = new System.Drawing.Point(751, 567);
            this.btnExcluirEquipa.Name = "btnExcluirEquipa";
            this.btnExcluirEquipa.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirEquipa.TabIndex = 42;
            this.btnExcluirEquipa.Text = "Excluir";
            this.btnExcluirEquipa.UseVisualStyleBackColor = true;
            this.btnExcluirEquipa.Click += new System.EventHandler(this.btnExcluirEquipa_Click);
            // 
            // btnAlterarEquipa
            // 
            this.btnAlterarEquipa.Location = new System.Drawing.Point(647, 567);
            this.btnAlterarEquipa.Name = "btnAlterarEquipa";
            this.btnAlterarEquipa.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarEquipa.TabIndex = 41;
            this.btnAlterarEquipa.Text = "Alterar";
            this.btnAlterarEquipa.UseVisualStyleBackColor = true;
            this.btnAlterarEquipa.Click += new System.EventHandler(this.btnAlterarEquipa_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(780, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 24);
            this.label2.TabIndex = 45;
            this.label2.Text = "CPF";
            // 
            // cmbResponsavelEquipa
            // 
            this.cmbResponsavelEquipa.FormattingEnabled = true;
            this.cmbResponsavelEquipa.Location = new System.Drawing.Point(504, 214);
            this.cmbResponsavelEquipa.Name = "cmbResponsavelEquipa";
            this.cmbResponsavelEquipa.Size = new System.Drawing.Size(243, 21);
            this.cmbResponsavelEquipa.TabIndex = 46;
            this.cmbResponsavelEquipa.SelectedIndexChanged += new System.EventHandler(this.cmbResponsavelEquipa_SelectedIndexChanged);
            // 
            // txtCPF
            // 
            this.txtCPF.Location = new System.Drawing.Point(784, 214);
            this.txtCPF.Name = "txtCPF";
            this.txtCPF.Size = new System.Drawing.Size(144, 20);
            this.txtCPF.TabIndex = 47;
            // 
            // frm_equipamentoOs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 628);
            this.Controls.Add(this.txtCPF);
            this.Controls.Add(this.cmbResponsavelEquipa);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCadastrarEquipa);
            this.Controls.Add(this.btnBuscarEquipa);
            this.Controls.Add(this.btnExcluirEquipa);
            this.Controls.Add(this.btnAlterarEquipa);
            this.Controls.Add(this.txtSenhaSeFornecEquipa);
            this.Controls.Add(this.txtEstadoFisEquipa);
            this.Controls.Add(this.txtNumeroSerieEquipa);
            this.Controls.Add(this.txtmodeloEquipa);
            this.Controls.Add(this.txtMarcaEquipa);
            this.Controls.Add(this.txtGarantiaEquipa);
            this.Controls.Add(this.txtCatEquipa);
            this.Controls.Add(this.txtNomeEquipa);
            this.Controls.Add(this.txtIdEquipa);
            this.Controls.Add(this.btnCarregarImagemEquipa);
            this.Controls.Add(this.pic_imageEquipa);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Name = "frm_equipamentoOs";
            this.Text = "frm_equipamentoOs";
            this.Load += new System.EventHandler(this.frm_equipamentoOs_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageEquipa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pic_imageEquipa;
        private System.Windows.Forms.Button btnCarregarImagemEquipa;
        private System.Windows.Forms.TextBox txtIdEquipa;
        private System.Windows.Forms.TextBox txtNomeEquipa;
        private System.Windows.Forms.TextBox txtCatEquipa;
        private System.Windows.Forms.TextBox txtGarantiaEquipa;
        private System.Windows.Forms.TextBox txtMarcaEquipa;
        private System.Windows.Forms.TextBox txtmodeloEquipa;
        private System.Windows.Forms.TextBox txtNumeroSerieEquipa;
        private System.Windows.Forms.TextBox txtEstadoFisEquipa;
        private System.Windows.Forms.TextBox txtSenhaSeFornecEquipa;
        private System.Windows.Forms.Button btnCadastrarEquipa;
        private System.Windows.Forms.Button btnBuscarEquipa;
        private System.Windows.Forms.Button btnExcluirEquipa;
        private System.Windows.Forms.Button btnAlterarEquipa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbResponsavelEquipa;
        private System.Windows.Forms.TextBox txtCPF;
    }
}