﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_buscaOrdensServico : Form
    {
        public frm_buscaOrdensServico()
        {
            InitializeComponent();
        }
        private void carregarOrdensServico()
        {
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = @"SELECT
                    IDOrdemServico AS ID,
                    NomeCliente,
                    NomeEquipamento,
                    DataEntrada,
                    DataSaida,
                    StatusOS,
                    ImagemEquipamento
                        FROM OrdensServico
                        ORDER BY DataEntrada";
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao);
                    DataTable tabela = new DataTable();
                    adapter.Fill(tabela);
                    dgvOS.DataSource = tabela;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar ordens de serviço:\n" + ex.Message);
            }
        }
























        private void btnBuscarOS_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtIdOS.Text, out int id))
                {
                    MessageBox.Show("Digite o ID da ordem de serviço.");
                    return;
                }

                using (SqlConnection conexao =
                    conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            NomeEquipamento,
                            CatEquipa,
                            PrevisaoEntregaOS,
                            StatusOS,
                            NumeroSerieEquipa,
                            NomeCliente,
                            TecResponsavel,
                            FotoEquipa
                        FROM OrdemServico 
                        INNER JOIN EquipamentosOS 
                            ON IDEquipa = IDEquipa
                        INNER JOIN Clientes 
                            ON IDCliente = IDCliente
                        WHERE IDOS = @IDOS";

                    SqlDataAdapter adapter =
                        new SqlDataAdapter(sql, conexao);

                    adapter.SelectCommand.Parameters.AddWithValue(
                        "@IDOS", id);

                    DataTable tabela = new DataTable();

                    adapter.Fill(tabela);

                    if (tabela.Rows.Count == 0)
                    {
                        dgvOS.DataSource = null;
                        pic_imageEquip.Image = null;

                        MessageBox.Show(
                            "Ordem de serviço não encontrada.");

                        return;
                    }

                    // Exibe os dados no DataGridView
                    DataTable dados = tabela.DefaultView.ToTable(
                        false,
                        "NomeEquipamento",
                        "CatEquipa",
                        "PrevisaoEntregaOS",
                        "StatusOS",
                        "NumeroSerieEquipa",
                        "NomeCliente",
                        "TecResponsavel");

                    dgvOS.DataSource = dados;

                    // Exibe a imagem do equipamento
                    pic_imageEquip.Image = null;
                    pic_imageEquip.SizeMode =
                        PictureBoxSizeMode.Zoom;

                    if (tabela.Rows[0]["FotoEquipa"] != DBNull.Value)
                    {
                        byte[] bytes =
                            (byte[])tabela.Rows[0]["FotoEquipa"];

                        using (MemoryStream memoria =
                            new MemoryStream(bytes))
                        using (Image imagem =
                            Image.FromStream(memoria))
                        {
                            pic_imageEquip.Image =
                                new Bitmap(imagem);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao buscar ordem de serviço:\n" +
                    ex.Message);
            }
        }

        private void pic_imageEquip_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Image imagemAnterior = pic_imageEquip.Image;
                    pic_imageEquip.Image = Image.FromFile(openFileDialog.FileName);
                    imagemAnterior?.Dispose();

                }
            }
        }

        private void frm_buscaOrdensServico_Load(object sender, EventArgs e)
        {

        }
    }
}
























        