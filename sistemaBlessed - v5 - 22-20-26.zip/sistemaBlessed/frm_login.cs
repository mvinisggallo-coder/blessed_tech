﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void frm_login_Load(object sender, EventArgs e)
        {

        }
        private void limparCampos()
        {
            txtUsuarioLogin.Clear();
            txtSenhaLogin.Clear();
            txtUsuarioLogin.Focus();
        }

        private void btnLoginLogin_Click(object sender, EventArgs e)
        {
            try
            {
                // Verifica se os campos estão preenchidos
                if (string.IsNullOrWhiteSpace(txtUsuarioLogin.Text) ||
                    string.IsNullOrWhiteSpace(txtSenhaLogin.Text))
                {
                    MessageBox.Show("Preencha o usuário e a senha!");
                    return;
                }

                // Abre a tela principal
                frm_menu tela = new frm_menu();
                tela.Show();

                // Oculta a tela de login
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir o sistema: " + ex.Message);
            }
        }
    }
}
