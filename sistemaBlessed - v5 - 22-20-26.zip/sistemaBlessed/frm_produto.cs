﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_produto : Form
    {
        public frm_produto()
        {
            InitializeComponent();
        }

        private void frm_produto_Load(object sender, EventArgs e)
        {
            txtIdProd.ReadOnly = true; // Impede que o usuário altere o ID do produto
        }
        private void LimparCampos()
        {
            txtNomeProd.Clear();
            txtDescProd.Clear();
            txtValorUnitProd.Clear();
            txtCatProd.Clear();
            txtCodBarrasProd.Clear();
            txtDataValidadeProd.Clear();
            txtMarcaProd.Clear();
            txtPesoProd.Clear();

            Image imagemAnterior = pic_imageProd.Image;
            pic_imageProd.Image = null;
            imagemAnterior?.Dispose();

            txtNomeProd.Focus();
        }

        private void btnCadastrarProd_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO produtos (nomeProduto, descricao, valorUnitario,CategoriaProduto,DataValidadeouGarantia, Peso, Marca, CodigodeBarras)" +
                                     "VALUES (@nomeProduto, @descricao, @valorUnitario, @CategoriaProduto, @DataValidadeouGarantia, @Peso, @Marca, @CodigodeBarras)";


                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@nomeProduto", txtNomeProd.Text);
                            comando.Parameters.AddWithValue("@descricao", txtDescProd.Text);
                            comando.Parameters.AddWithValue("@valorUnitario", txtValorUnitProd.Text);
                            comando.Parameters.AddWithValue("@CategoriaProduto", txtCatProd.Text);
                            comando.Parameters.AddWithValue("@DataValidadeouGarantia", txtDataValidadeProd.Text);
                            comando.Parameters.AddWithValue("@Peso", txtPesoProd.Text);
                            comando.Parameters.AddWithValue("@Marca", txtMarcaProd.Text);
                            comando.Parameters.AddWithValue("@CodigodeBarras", txtCodBarrasProd.Text);
                            comando.ExecuteNonQuery();
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Produto cadastrado com sucesso!");
                                LimparCampos();
                            }
                            else
                            {
                                MessageBox.Show("Falha ao cadastrar o produto.");
                            }
                        }
                    }

                }

                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar o produto: " + ex.Message);
                }
            }
        }

        private void btnCarregarImagemProd_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Image imagemAnterior = pic_imageProd.Image;
                    pic_imageProd.Image = Image.FromFile(openFileDialog.FileName);
                    imagemAnterior?.Dispose();
                }
            }
        }
    }
}


