﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sistemaBlessed
{
    public partial class frm_equipamentoOs : Form
    {
        public frm_equipamentoOs()
        {
            InitializeComponent();
        }

        private void frm_equipamentoOs_Load(object sender, EventArgs e)
        {
            txtIdEquipa.ReadOnly = true; // Impede que o usuário altere o ID do equipamento
        }
        private void LimparCampos()
        {
            txtIdCliEquipa.Clear();
            txtNomeCliEquipa.Clear();
            txtNomeEquipa.Clear();
            txtGarantiaEquipa.Clear();
            txtCatEquipa.Clear();
            txtEstadoFisEquipa.Clear();
            txtMarcaEquipa.Clear();
            txtmodeloEquipa.Clear();
            txtNumeroSerieEquipa.Clear();
            txtSenhaSeFornecEquipa.Clear();

            txtNomeEquipa.Focus();
        }
        private void btnCadastrarEquipa_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = "INSERT INTO equipamentosOS (NomeEquipamento, CatEquipa, GarantiaEquipa, NumeroSerieEquipa, MarcaEquipa,ModeloEquipa, EstadoFisicoEquipa, SenhaSeFornecEquipa)" +

                            "VALUES (@NomeEquipamento, @CatEquipa, @GarantiaEquipa, @NumeroSerieEquipa, @MarcaEquipa, @ModeloEquipa, @EstadoFisicoEquipa, @SenhaSeFornecEquipa)";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                            comando.Parameters.AddWithValue("@CatEquipa", txtCatEquipa.Text);
                            comando.Parameters.AddWithValue("@GarantiaEquipa", txtGarantiaEquipa.Text);
                            comando.Parameters.AddWithValue("@NumeroSerieEquipa", txtNumeroSerieEquipa.Text);
                            comando.Parameters.AddWithValue("@MarcaEquipa", txtMarcaEquipa.Text);
                            comando.Parameters.AddWithValue("@ModeloEquipa", txtmodeloEquipa.Text);
                            comando.Parameters.AddWithValue("@EstadoFisicoEquipa", txtEstadoFisEquipa.Text);
                            comando.Parameters.AddWithValue("@SenhaSeFornecEquipa", txtSenhaSeFornecEquipa.Text);
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Equipamento cadastrado com sucesso!");
                                LimparCampos();
                            }
                            else
                            {
                                MessageBox.Show("Falha ao cadastrar equipamento.");
                            }





                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar equipamento: " + ex.Message);

                }
            }

        }

        private void btnCarregarImagemEquipa_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pic_imageEquipa.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
        }
    }
}
