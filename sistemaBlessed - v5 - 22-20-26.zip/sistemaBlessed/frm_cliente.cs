﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_cliente : Form
    {
        public frm_cliente()
        {
            InitializeComponent();
        }

        private void frm_cliente_Load(object sender, EventArgs e)
        {
            txtIDCli.ReadOnly = true;

            // Adiciona as opções ao ComboBox
            cmbTipoPessoaCli.Items.Clear();
            cmbTipoPessoaCli.Items.Add("Física");
            cmbTipoPessoaCli.Items.Add("Jurídica");

            // Impede que o usuário digite outras opções
            cmbTipoPessoaCli.DropDownStyle = ComboBoxStyle.DropDownList;

            // Seleciona Ativo como padrão
            cmbTipoPessoaCli.SelectedIndex = 0;
        }

        private void LimparCampos()
        {
            
            txtNomeCli.Clear();
            txtTeleCli.Clear();
            txtEmailCli.Clear();
            txtCpfouCnpjCli.Clear();
            txtDataNascCli.Clear();
            txtCEPCli.Clear();
            txtCidadeCli.Clear();
            txtEstadoCli.Clear();
            txtRuaouAvenidaCli.Clear();
            txtNumeroCli.Clear();
            txtBairroCli.Clear();
            txtComplementoCli.Clear();

            // Volta o status para Ativo
            cmbTipoPessoaCli.SelectedIndex = 0;


            // Posiciona o cursor no nome
            txtNomeCli.Focus();
        }

        private void btnCadastrarCli_Click(object sender, EventArgs e)
        {
            {
                {

                    try
                    {
                        using (SqlConnection conexao = conexao_banco.CriarConexao())
                        {
                            conexao.Open();

                            string sql = "INSERT INTO Clientes (NomeCliente, CPF, DataNasc, TipoPessoa, Telefone, Email, CEP, Cidade, Estado, RuaOuAvenida, Numero, Bairro, Complemento)" +
                                "VALUES (@NomeCliente, @CPF, @DataNasc, @TipoPessoa, @Telefone, @Email, @CEP, @Cidade, @Estado, @RuaOuAvenida, @Numero, @Bairro, @Complemento)";

                            using (SqlCommand comando = new SqlCommand(sql, conexao))
                            {
                                comando.Parameters.AddWithValue("@IDCliente", txtNomeCli.Text);                          
                                comando.Parameters.AddWithValue("@NomeCliente", txtNomeCli.Text);
                                comando.Parameters.AddWithValue("@CPF", txtCpfouCnpjCli.Text);
                                comando.Parameters.AddWithValue("@DataNasc", txtDataNascCli.Text);
                                comando.Parameters.AddWithValue("@TipoPessoa", cmbTipoPessoaCli.SelectedItem.ToString());
                                comando.Parameters.AddWithValue("@Telefone", txtTeleCli.Text);
                                comando.Parameters.AddWithValue("@Email", txtEmailCli.Text);
                                comando.Parameters.AddWithValue("@CEP", txtCEPCli.Text);
                                comando.Parameters.AddWithValue("@Cidade", txtCidadeCli.Text);
                                comando.Parameters.AddWithValue("@Estado", txtEstadoCli.Text);
                                comando.Parameters.AddWithValue("@RuaOuAvenida", txtRuaouAvenidaCli.Text);
                                comando.Parameters.AddWithValue("@Numero", txtNumeroCli.Text);
                                comando.Parameters.AddWithValue("@Bairro", txtBairroCli.Text);
                                comando.Parameters.AddWithValue("@Complemento", txtComplementoCli.Text);
                                comando.Parameters.AddWithValue(
                                 "@StatusFunc", cmbTipoPessoaCli.SelectedItem.ToString());

                                int linhasAfetadas = comando.ExecuteNonQuery();


                                if (linhasAfetadas > 0)
                                {
                                    MessageBox.Show("Cliente cadastrado com sucesso!");

                                    LimparCampos();
                                }

                            }

                        }

                        LimparCampos();

                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Erro ao cadastrar Cliente: " + ex.Message);
                    }
                }
            }
        }
    }
}
























                    

                    
        

    
    


                    
            



























        
    
    
