﻿namespace sistemaBlessed
{
    partial class frm_funcionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtIdFunc = new System.Windows.Forms.TextBox();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.txtSalarioFunc = new System.Windows.Forms.TextBox();
            this.txtCPFFunc = new System.Windows.Forms.TextBox();
            this.txtTeleFunc = new System.Windows.Forms.TextBox();
            this.txtEmailFunc = new System.Windows.Forms.TextBox();
            this.cmbCargoFunc = new System.Windows.Forms.ComboBox();
            this.pic_imageFunc = new System.Windows.Forms.PictureBox();
            this.btnAlterarFunc = new System.Windows.Forms.Button();
            this.btnExcluirFunc = new System.Windows.Forms.Button();
            this.btnBuscarFunc = new System.Windows.Forms.Button();
            this.btnCadastrarFunc = new System.Windows.Forms.Button();
            this.cmbStatusFunc = new System.Windows.Forms.ComboBox();
            this.btnCarregarImagemFunc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageFunc)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(40, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(650, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de Funcionários";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(51, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(51, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nome";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(315, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "CPF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label5.Location = new System.Drawing.Point(319, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Cargo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label6.Location = new System.Drawing.Point(53, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(675, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Imagem do Funcionário";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(51, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "Telefone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label9.Location = new System.Drawing.Point(53, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Salário";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(243, 325);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Status";
            // 
            // txtIdFunc
            // 
            this.txtIdFunc.Location = new System.Drawing.Point(79, 91);
            this.txtIdFunc.Name = "txtIdFunc";
            this.txtIdFunc.Size = new System.Drawing.Size(100, 20);
            this.txtIdFunc.TabIndex = 10;
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(53, 184);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(471, 20);
            this.txtNomeFunc.TabIndex = 11;
            // 
            // txtSalarioFunc
            // 
            this.txtSalarioFunc.Location = new System.Drawing.Point(52, 351);
            this.txtSalarioFunc.Name = "txtSalarioFunc";
            this.txtSalarioFunc.Size = new System.Drawing.Size(106, 20);
            this.txtSalarioFunc.TabIndex = 12;
            // 
            // txtCPFFunc
            // 
            this.txtCPFFunc.Location = new System.Drawing.Point(317, 238);
            this.txtCPFFunc.Name = "txtCPFFunc";
            this.txtCPFFunc.Size = new System.Drawing.Size(155, 20);
            this.txtCPFFunc.TabIndex = 13;
            // 
            // txtTeleFunc
            // 
            this.txtTeleFunc.Location = new System.Drawing.Point(53, 239);
            this.txtTeleFunc.Name = "txtTeleFunc";
            this.txtTeleFunc.Size = new System.Drawing.Size(171, 20);
            this.txtTeleFunc.TabIndex = 15;
            // 
            // txtEmailFunc
            // 
            this.txtEmailFunc.Location = new System.Drawing.Point(53, 293);
            this.txtEmailFunc.Name = "txtEmailFunc";
            this.txtEmailFunc.Size = new System.Drawing.Size(238, 20);
            this.txtEmailFunc.TabIndex = 16;
            // 
            // cmbCargoFunc
            // 
            this.cmbCargoFunc.FormattingEnabled = true;
            this.cmbCargoFunc.Items.AddRange(new object[] {
            "Técnico ",
            "Gerente"});
            this.cmbCargoFunc.Location = new System.Drawing.Point(319, 293);
            this.cmbCargoFunc.Name = "cmbCargoFunc";
            this.cmbCargoFunc.Size = new System.Drawing.Size(153, 21);
            this.cmbCargoFunc.TabIndex = 17;
            // 
            // pic_imageFunc
            // 
            this.pic_imageFunc.Location = new System.Drawing.Point(668, 173);
            this.pic_imageFunc.Name = "pic_imageFunc";
            this.pic_imageFunc.Size = new System.Drawing.Size(234, 245);
            this.pic_imageFunc.TabIndex = 19;
            this.pic_imageFunc.TabStop = false;
            // 
            // btnAlterarFunc
            // 
            this.btnAlterarFunc.Location = new System.Drawing.Point(592, 473);
            this.btnAlterarFunc.Name = "btnAlterarFunc";
            this.btnAlterarFunc.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarFunc.TabIndex = 20;
            this.btnAlterarFunc.Text = "Alterar";
            this.btnAlterarFunc.UseVisualStyleBackColor = true;
            // 
            // btnExcluirFunc
            // 
            this.btnExcluirFunc.Location = new System.Drawing.Point(696, 473);
            this.btnExcluirFunc.Name = "btnExcluirFunc";
            this.btnExcluirFunc.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirFunc.TabIndex = 21;
            this.btnExcluirFunc.Text = "Excluir";
            this.btnExcluirFunc.UseVisualStyleBackColor = true;
            // 
            // btnBuscarFunc
            // 
            this.btnBuscarFunc.Location = new System.Drawing.Point(798, 473);
            this.btnBuscarFunc.Name = "btnBuscarFunc";
            this.btnBuscarFunc.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarFunc.TabIndex = 22;
            this.btnBuscarFunc.Text = "Buscar";
            this.btnBuscarFunc.UseVisualStyleBackColor = true;
            // 
            // btnCadastrarFunc
            // 
            this.btnCadastrarFunc.Location = new System.Drawing.Point(488, 473);
            this.btnCadastrarFunc.Name = "btnCadastrarFunc";
            this.btnCadastrarFunc.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarFunc.TabIndex = 23;
            this.btnCadastrarFunc.Text = "Cadastrar";
            this.btnCadastrarFunc.UseVisualStyleBackColor = true;
            this.btnCadastrarFunc.Click += new System.EventHandler(this.btnCadastrarFunc_Click);
            // 
            // cmbStatusFunc
            // 
            this.cmbStatusFunc.FormattingEnabled = true;
            this.cmbStatusFunc.Items.AddRange(new object[] {
            "ATIVO",
            "NÃO ATIVO"});
            this.cmbStatusFunc.Location = new System.Drawing.Point(247, 350);
            this.cmbStatusFunc.Name = "cmbStatusFunc";
            this.cmbStatusFunc.Size = new System.Drawing.Size(112, 21);
            this.cmbStatusFunc.TabIndex = 24;
            // 
            // btnCarregarImagemFunc
            // 
            this.btnCarregarImagemFunc.Location = new System.Drawing.Point(717, 424);
            this.btnCarregarImagemFunc.Name = "btnCarregarImagemFunc";
            this.btnCarregarImagemFunc.Size = new System.Drawing.Size(116, 23);
            this.btnCarregarImagemFunc.TabIndex = 25;
            this.btnCarregarImagemFunc.Text = "Carregar Imagem";
            this.btnCarregarImagemFunc.UseVisualStyleBackColor = true;
            this.btnCarregarImagemFunc.Click += new System.EventHandler(this.btnCarregarImagemFunc_Click);
            // 
            // frm_funcionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 544);
            this.Controls.Add(this.btnCarregarImagemFunc);
            this.Controls.Add(this.cmbStatusFunc);
            this.Controls.Add(this.btnCadastrarFunc);
            this.Controls.Add(this.btnBuscarFunc);
            this.Controls.Add(this.btnExcluirFunc);
            this.Controls.Add(this.btnAlterarFunc);
            this.Controls.Add(this.pic_imageFunc);
            this.Controls.Add(this.cmbCargoFunc);
            this.Controls.Add(this.txtEmailFunc);
            this.Controls.Add(this.txtTeleFunc);
            this.Controls.Add(this.txtCPFFunc);
            this.Controls.Add(this.txtSalarioFunc);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.txtIdFunc);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_funcionario";
            this.Text = "frm_funcionario";
            this.Load += new System.EventHandler(this.frm_funcionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageFunc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtIdFunc;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.TextBox txtSalarioFunc;
        private System.Windows.Forms.TextBox txtCPFFunc;
        private System.Windows.Forms.TextBox txtTeleFunc;
        private System.Windows.Forms.TextBox txtEmailFunc;
        private System.Windows.Forms.ComboBox cmbCargoFunc;
        private System.Windows.Forms.PictureBox pic_imageFunc;
        private System.Windows.Forms.Button btnAlterarFunc;
        private System.Windows.Forms.Button btnExcluirFunc;
        private System.Windows.Forms.Button btnBuscarFunc;
        private System.Windows.Forms.Button btnCadastrarFunc;
        private System.Windows.Forms.ComboBox cmbStatusFunc;
        private System.Windows.Forms.Button btnCarregarImagemFunc;
    }
}