﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_menu : Form
    {
        public frm_menu()
        {
            InitializeComponent();
        }

    

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void gerenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_gerente tela = new frm_gerente();
            tela.Show();
        }

        private void funcionárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_funcionario tela = new frm_funcionario();
            tela.Show();
        }

        private void equipamentoParaOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_equipamentoOs tela = new frm_equipamentoOs();
            tela.Show();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_produto tela = new frm_produto();
            tela.Show();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_cliente tela = new frm_cliente();
            tela.Show();    
        }

        private void fornecedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_fornecedor tela = new frm_fornecedor();
            tela.Show();
        }

        private void vendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_vendas tela = new frm_vendas();
            tela.Show();
        }

        private void ordemDeServiçoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_ordemServico tela = new frm_ordemServico();
            tela.Show();    
        }

        

        private void movimentaçãoDoEstoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_estoque tela = new frm_estoque();
            tela.Show();
        }





        private void buscasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fornedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_buscaFornecedores tela = new frm_buscaFornecedores();
            tela.Show();
        }

        private void ordemDeServiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_buscaOrdensServico tela = new frm_buscaOrdensServico();
            tela.Show();
        }

        private void estoqueToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frm_movimentacaoEstoque tela = new frm_movimentacaoEstoque();
            tela.Show();
        }
    }
}

