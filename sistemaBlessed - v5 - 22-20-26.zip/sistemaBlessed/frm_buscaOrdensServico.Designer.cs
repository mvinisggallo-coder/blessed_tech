﻿namespace sistemaBlessed
{
    partial class frm_buscaOrdensServico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnBuscarOS = new System.Windows.Forms.Button();
            this.txtIdOS = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDiagTecEquip = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.dgvOS = new System.Windows.Forms.DataGridView();
            this.btnCarregarImagemEquip = new System.Windows.Forms.Button();
            this.pic_imageEquip = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageEquip)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(717, 69);
            this.label1.TabIndex = 3;
            this.label1.Text = "Busca de Ordens de Serviço";
            // 
            // btnBuscarOS
            // 
            this.btnBuscarOS.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 14.25F, System.Drawing.FontStyle.Italic);
            this.btnBuscarOS.Location = new System.Drawing.Point(191, 105);
            this.btnBuscarOS.Name = "btnBuscarOS";
            this.btnBuscarOS.Size = new System.Drawing.Size(96, 32);
            this.btnBuscarOS.TabIndex = 55;
            this.btnBuscarOS.Text = "Buscar";
            this.btnBuscarOS.UseVisualStyleBackColor = true;
            // 
            // txtIdOS
            // 
            this.txtIdOS.Location = new System.Drawing.Point(56, 114);
            this.txtIdOS.Name = "txtIdOS";
            this.txtIdOS.Size = new System.Drawing.Size(100, 20);
            this.txtIdOS.TabIndex = 54;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(28, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 53;
            this.label10.Text = "ID";
            // 
            // txtDiagTecEquip
            // 
            this.txtDiagTecEquip.Location = new System.Drawing.Point(32, 418);
            this.txtDiagTecEquip.Multiline = true;
            this.txtDiagTecEquip.Name = "txtDiagTecEquip";
            this.txtDiagTecEquip.Size = new System.Drawing.Size(1078, 73);
            this.txtDiagTecEquip.TabIndex = 83;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(30, 393);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(185, 20);
            this.label23.TabIndex = 82;
            this.label23.Text = "Diagnóstico do Técnico";
            // 
            // dgvOS
            // 
            this.dgvOS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOS.Location = new System.Drawing.Point(32, 157);
            this.dgvOS.Name = "dgvOS";
            this.dgvOS.Size = new System.Drawing.Size(697, 207);
            this.dgvOS.TabIndex = 84;
            // 
            // btnCarregarImagemEquip
            // 
            this.btnCarregarImagemEquip.Location = new System.Drawing.Point(892, 370);
            this.btnCarregarImagemEquip.Name = "btnCarregarImagemEquip";
            this.btnCarregarImagemEquip.Size = new System.Drawing.Size(116, 23);
            this.btnCarregarImagemEquip.TabIndex = 87;
            this.btnCarregarImagemEquip.Text = "Carregar Imagem";
            this.btnCarregarImagemEquip.UseVisualStyleBackColor = true;
            // 
            // pic_imageEquip
            // 
            this.pic_imageEquip.Location = new System.Drawing.Point(803, 131);
            this.pic_imageEquip.Name = "pic_imageEquip";
            this.pic_imageEquip.Size = new System.Drawing.Size(297, 233);
            this.pic_imageEquip.TabIndex = 86;
            this.pic_imageEquip.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label13.Location = new System.Drawing.Point(834, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(239, 24);
            this.label13.TabIndex = 85;
            this.label13.Text = "Imagem do Equipamento";
            // 
            // frm_buscaOrdensServico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 526);
            this.Controls.Add(this.btnCarregarImagemEquip);
            this.Controls.Add(this.pic_imageEquip);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dgvOS);
            this.Controls.Add(this.txtDiagTecEquip);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.btnBuscarOS);
            this.Controls.Add(this.txtIdOS);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Name = "frm_buscaOrdensServico";
            this.Text = "frm_buscaOrdensServico";
            ((System.ComponentModel.ISupportInitialize)(this.dgvOS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageEquip)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBuscarOS;
        private System.Windows.Forms.TextBox txtIdOS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDiagTecEquip;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dgvOS;
        private System.Windows.Forms.Button btnCarregarImagemEquip;
        private System.Windows.Forms.PictureBox pic_imageEquip;
        private System.Windows.Forms.Label label13;
    }
}