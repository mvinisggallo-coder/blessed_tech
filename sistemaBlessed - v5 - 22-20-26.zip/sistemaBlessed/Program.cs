﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    internal static class Program
    {
        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frm_login());
            Application.Run(new frm_menu());
            Application.Run(new frm_cliente());
            Application.Run(new frm_gerente());
            Application.Run(new frm_funcionario());
            
        }
    }
    }

