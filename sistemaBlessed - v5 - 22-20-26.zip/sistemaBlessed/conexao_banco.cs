﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaBlessed
{
    internal class conexao_banco
    {
        //Servidor
        private static string servidor = @"Localhost";

        // banco de dados
        private static string banco = "DBAssistenciaBlessed";

        // usuário e senha SQL Server

        private static string usuario = "sa";

        private static string senha = "sasenac";

        public static string StringConexao
        {
            get
            {
                return @"Data Source=" + servidor +
                   ";Initial Catalog=" + banco +
                   ";User ID=" + usuario +
                   ";Password=" + senha +
                   ";TrustServerCertificate=True;";

            }

        }
        public static SqlConnection CriarConexao()
        {
            return new SqlConnection(StringConexao);

        }


    }
}
