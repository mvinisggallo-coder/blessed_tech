﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_funcionario : Form
    {
        public frm_funcionario()
        {
            InitializeComponent();
        }

        private void frm_funcionario_Load(object sender, EventArgs e)
        {
            txtIdFunc.ReadOnly = true;
        }
        private void LimparCampos()
        {
            txtNomeFunc.Clear();          
            txtTeleFunc.Clear();
            txtEmailFunc.Clear();
            txtCPFFunc.Clear();
            txtSalarioFunc.Clear();

            // Volta o status para Ativo
            cmbStatusFunc.SelectedIndex = 0;

            // Remove a imagem
            Image imagemAnterior = pic_imageFunc.Image;
            pic_imageFunc.Image = null;
            imagemAnterior?.Dispose();

            // Posiciona o cursor no nome
            txtNomeFunc.Focus();

        }

        private void btnCadastrarFunc_Click(object sender, EventArgs e)
        {
            {

                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO Funcionários (NomeFunc, CPF, Telefone, Email, Salario, Cargo, Imagem, StatusFunc)" +
                            "VALUES (@NomeFunc, @CPF, @Telefone, @Email, @Salario, @Cargo, @Imagem,  @StatusFunc)";

                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeFunc", txtNomeFunc.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCPFFunc.Text); 
                            comando.Parameters.AddWithValue("@Telefone", txtTeleFunc.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailFunc.Text);
                            comando.Parameters.AddWithValue("@Salario", txtSalarioFunc.Text);
                        
                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusFunc", cmbStatusFunc.SelectedItem.ToString());

                            // ComboBox - Cargo
                            comando.Parameters.AddWithValue(
                                "@Cargo", cmbCargoFunc.SelectedItem.ToString());


                            // PictureBox - Imagem
                            if (pic_imageFunc.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imageFunc.Image.Save(
                                        ms, System.Drawing.Imaging.ImageFormat.Png);

                                    byte[] imagemBytes = ms.ToArray();

                                    comando.Parameters.Add(
                                        "@Imagem", SqlDbType.VarBinary, -1).Value =
                                        imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add(
                                    "@Imagem", SqlDbType.VarBinary, -1).Value =
                                    DBNull.Value;
                            }


                            int linhasAfetadas = comando.ExecuteNonQuery();


                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Funcionário cadastrado com sucesso!");

                                LimparCampos();
                            }

                            }

                    }

                    LimparCampos();

                }
                catch (Exception ex)
                {

                    MessageBox.Show("Erro ao cadastrar Funcionário: " + ex.Message);
                }
            }





































        }

        private void btnCarregarImagemFunc_Click(object sender, EventArgs e)
        {
            // Abre a janela para selecionar uma imagem
            using (OpenFileDialog abrir = new OpenFileDialog())
            {
                // Permite selecionar apenas imagens
                abrir.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp";

                // Abre a janela de seleção
                if (abrir.ShowDialog() == DialogResult.OK)
                {
                    // Carrega a imagem sem manter o arquivo bloqueado
                    byte[] bytes = System.IO.File.ReadAllBytes(abrir.FileName);

                    using (MemoryStream ms = new MemoryStream(bytes))
                    using (Image imagem = Image.FromStream(ms))
                    {
                        Image imagemAnterior = pic_imageFunc.Image;

                        pic_imageFunc.Image = new Bitmap(imagem);

                        imagemAnterior?.Dispose();
                    }
                }
            }
        }
    }
    }

