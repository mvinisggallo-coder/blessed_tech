﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace sistemaBlessed
{
    public partial class frm_fornecedor : Form
    {
        public frm_fornecedor()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void frm_fornecedor_Load(object sender, EventArgs e)
        {
            txtIdFor.ReadOnly = true; // Impede que o usuário altere o ID do fornecedor

            cmbStatusFor.Items.Clear();
            cmbStatusFor.Items.Add("Ativo");
            cmbStatusFor.Items.Add("Inativo");
            cmbStatusFor.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbTipoPessoaFor.Items.Clear();
            cmbTipoPessoaFor.Items.Add("Física");
            cmbTipoPessoaFor.Items.Add("Jurídica");
            cmbTipoPessoaFor.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        private void LimparCampos()
        {
            txtNomeFor.Clear();
            txtCpfouCnpjFor.Clear();
            txtTeleFor.Clear();
            txtEmailFor.Clear();
            txtInscricaoEstFor.Clear();
            txtNumeroFor.Clear();
            txtBairroFor.Clear();
            txtComplementoFor.Clear();
            txtRuaouAvenidaFor.Clear();
            txtCEPFor.Clear();
            txtCidadeFor.Clear();
            txtEstadoFor.Clear();
            txtNacionaliFor.Clear();

            cmbStatusFor.SelectedIndex = 0;

            cmbTipoPessoaFor.SelectedIndex = 0;


            Image imagemAnterior = pic_imagemFor.Image;
            pic_imagemFor.Image = null;
            imagemAnterior?.Dispose();

            txtNomeFor.Focus();
        }

        private void btnCadastrarFor_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO Fornecedores (NomeFornecdor, TipoPessoa, CNPJouCPF, Telefone, Email, InscricaoEstadual, Numero, Bairro, Complemento, RuaOuAvenida, CEP, Cidade, Estado, Nacionalidade, StatusFornecedor) " +
                                       "VALUES (@NomeFornecdor, @TipoPessoa, @CNPJouCPF, @Telefone, @Email, @InscricaoEstadual, @Numero, @Bairro, @Complemento, @RuaOuAvenida, @CEP, @Cidade, @Estado, @Nacionalidade, @StatusFornecedor)";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeFornecdor", txtNomeFor.Text);
                            comando.Parameters.AddWithValue("@CNPJouCPF", txtCpfouCnpjFor.Text);
                            comando.Parameters.AddWithValue("@Telefone", txtTeleFor.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailFor.Text);
                            comando.Parameters.AddWithValue("@InscricaoEstadual", txtInscricaoEstFor.Text);
                            comando.Parameters.AddWithValue("@Numero", txtNumeroFor.Text);
                            comando.Parameters.AddWithValue("@Bairro", txtBairroFor.Text);
                            comando.Parameters.AddWithValue("@Complemento", txtComplementoFor.Text);
                            comando.Parameters.AddWithValue("@RuaOuAvenida", txtRuaouAvenidaFor.Text);
                            comando.Parameters.AddWithValue("@CEP", txtCEPFor.Text);
                            comando.Parameters.AddWithValue("@Cidade", txtCidadeFor.Text);
                            comando.Parameters.AddWithValue("@Estado", txtEstadoFor.Text);
                            comando.Parameters.AddWithValue("@Nacionalidade", txtNacionaliFor.Text);
                            comando.Parameters.AddWithValue("@StatusFornecedor", cmbStatusFor.SelectedItem.ToString());
                            comando.Parameters.AddWithValue("@TipoPessoa", cmbTipoPessoaFor.SelectedItem.ToString());
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Fornecedor cadastrado com sucesso!");
                                LimparCampos();
                            }
                            else
                            {
                                MessageBox.Show("Erro ao cadastrar fornecedor.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar fornecedor: " + ex.Message);
                }
            }
        }

        private void btnCarregarImagemFor_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Image imagemAnterior = pic_imagemFor.Image;
                    pic_imagemFor.Image = Image.FromFile(openFileDialog.FileName);
                    imagemAnterior?.Dispose();
                }
            }
        }
    }
}


