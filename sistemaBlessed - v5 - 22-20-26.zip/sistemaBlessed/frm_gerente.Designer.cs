﻿namespace sistemaBlessed
{
    partial class frm_gerente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtIDGer = new System.Windows.Forms.TextBox();
            this.txtNomeGer = new System.Windows.Forms.TextBox();
            this.txtDataNascGer = new System.Windows.Forms.TextBox();
            this.txtCPFGer = new System.Windows.Forms.TextBox();
            this.txtEmailGer = new System.Windows.Forms.TextBox();
            this.txtTelefoneGer = new System.Windows.Forms.TextBox();
            this.txtSalarioGer = new System.Windows.Forms.TextBox();
            this.cmbStatusGer = new System.Windows.Forms.ComboBox();
            this.pic_imagemGer = new System.Windows.Forms.PictureBox();
            this.btn_CadastrarGer = new System.Windows.Forms.Button();
            this.btn_AlterarGer = new System.Windows.Forms.Button();
            this.btn_BuscarGer = new System.Windows.Forms.Button();
            this.btn_ExcluirGer = new System.Windows.Forms.Button();
            this.btnCarregarImagemGer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemGer)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(34, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(561, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de Gerentes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(54, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(263, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "CPF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(50, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(192, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Data de Nascimento";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(226, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(55, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Nome";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(51, 273);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "Email";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(51, 337);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Salário";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(341, 274);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Telefone";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(722, 123);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(191, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Imagem do Gerente";
            // 
            // txtIDGer
            // 
            this.txtIDGer.Location = new System.Drawing.Point(82, 94);
            this.txtIDGer.Name = "txtIDGer";
            this.txtIDGer.Size = new System.Drawing.Size(100, 20);
            this.txtIDGer.TabIndex = 11;
            // 
            // txtNomeGer
            // 
            this.txtNomeGer.Location = new System.Drawing.Point(56, 182);
            this.txtNomeGer.Name = "txtNomeGer";
            this.txtNomeGer.Size = new System.Drawing.Size(475, 20);
            this.txtNomeGer.TabIndex = 12;
            // 
            // txtDataNascGer
            // 
            this.txtDataNascGer.Location = new System.Drawing.Point(53, 241);
            this.txtDataNascGer.Name = "txtDataNascGer";
            this.txtDataNascGer.Size = new System.Drawing.Size(121, 20);
            this.txtDataNascGer.TabIndex = 13;
            // 
            // txtCPFGer
            // 
            this.txtCPFGer.Location = new System.Drawing.Point(262, 241);
            this.txtCPFGer.Name = "txtCPFGer";
            this.txtCPFGer.Size = new System.Drawing.Size(153, 20);
            this.txtCPFGer.TabIndex = 14;
            // 
            // txtEmailGer
            // 
            this.txtEmailGer.Location = new System.Drawing.Point(53, 300);
            this.txtEmailGer.Name = "txtEmailGer";
            this.txtEmailGer.Size = new System.Drawing.Size(239, 20);
            this.txtEmailGer.TabIndex = 15;
            // 
            // txtTelefoneGer
            // 
            this.txtTelefoneGer.Location = new System.Drawing.Point(343, 300);
            this.txtTelefoneGer.Name = "txtTelefoneGer";
            this.txtTelefoneGer.Size = new System.Drawing.Size(188, 20);
            this.txtTelefoneGer.TabIndex = 16;
            // 
            // txtSalarioGer
            // 
            this.txtSalarioGer.Location = new System.Drawing.Point(53, 363);
            this.txtSalarioGer.Name = "txtSalarioGer";
            this.txtSalarioGer.Size = new System.Drawing.Size(109, 20);
            this.txtSalarioGer.TabIndex = 17;
            // 
            // cmbStatusGer
            // 
            this.cmbStatusGer.FormattingEnabled = true;
            this.cmbStatusGer.Items.AddRange(new object[] {
            "ATIVO",
            "NÃO ATIVO"});
            this.cmbStatusGer.Location = new System.Drawing.Point(228, 364);
            this.cmbStatusGer.Name = "cmbStatusGer";
            this.cmbStatusGer.Size = new System.Drawing.Size(121, 21);
            this.cmbStatusGer.TabIndex = 18;
            // 
            // pic_imagemGer
            // 
            this.pic_imagemGer.Location = new System.Drawing.Point(698, 158);
            this.pic_imagemGer.Name = "pic_imagemGer";
            this.pic_imagemGer.Size = new System.Drawing.Size(241, 250);
            this.pic_imagemGer.TabIndex = 19;
            this.pic_imagemGer.TabStop = false;
            // 
            // btn_CadastrarGer
            // 
            this.btn_CadastrarGer.Location = new System.Drawing.Point(557, 488);
            this.btn_CadastrarGer.Name = "btn_CadastrarGer";
            this.btn_CadastrarGer.Size = new System.Drawing.Size(75, 23);
            this.btn_CadastrarGer.TabIndex = 20;
            this.btn_CadastrarGer.Text = "Cadastrar";
            this.btn_CadastrarGer.UseVisualStyleBackColor = true;
            this.btn_CadastrarGer.Click += new System.EventHandler(this.btn_CadastrarGer_Click);
            // 
            // btn_AlterarGer
            // 
            this.btn_AlterarGer.Location = new System.Drawing.Point(659, 488);
            this.btn_AlterarGer.Name = "btn_AlterarGer";
            this.btn_AlterarGer.Size = new System.Drawing.Size(75, 23);
            this.btn_AlterarGer.TabIndex = 21;
            this.btn_AlterarGer.Text = "Alterar";
            this.btn_AlterarGer.UseVisualStyleBackColor = true;
            // 
            // btn_BuscarGer
            // 
            this.btn_BuscarGer.Location = new System.Drawing.Point(854, 488);
            this.btn_BuscarGer.Name = "btn_BuscarGer";
            this.btn_BuscarGer.Size = new System.Drawing.Size(75, 23);
            this.btn_BuscarGer.TabIndex = 22;
            this.btn_BuscarGer.Text = "Buscar";
            this.btn_BuscarGer.UseVisualStyleBackColor = true;
            // 
            // btn_ExcluirGer
            // 
            this.btn_ExcluirGer.Location = new System.Drawing.Point(757, 488);
            this.btn_ExcluirGer.Name = "btn_ExcluirGer";
            this.btn_ExcluirGer.Size = new System.Drawing.Size(75, 23);
            this.btn_ExcluirGer.TabIndex = 23;
            this.btn_ExcluirGer.Text = "Excluir";
            this.btn_ExcluirGer.UseVisualStyleBackColor = true;
            // 
            // btnCarregarImagemGer
            // 
            this.btnCarregarImagemGer.Location = new System.Drawing.Point(763, 414);
            this.btnCarregarImagemGer.Name = "btnCarregarImagemGer";
            this.btnCarregarImagemGer.Size = new System.Drawing.Size(105, 23);
            this.btnCarregarImagemGer.TabIndex = 24;
            this.btnCarregarImagemGer.Text = "Carregar Imagem";
            this.btnCarregarImagemGer.UseVisualStyleBackColor = true;
            this.btnCarregarImagemGer.Click += new System.EventHandler(this.btnCarregarImagemGer_Click);
            // 
            // frm_gerente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 558);
            this.Controls.Add(this.btnCarregarImagemGer);
            this.Controls.Add(this.btn_ExcluirGer);
            this.Controls.Add(this.btn_BuscarGer);
            this.Controls.Add(this.btn_AlterarGer);
            this.Controls.Add(this.btn_CadastrarGer);
            this.Controls.Add(this.pic_imagemGer);
            this.Controls.Add(this.cmbStatusGer);
            this.Controls.Add(this.txtSalarioGer);
            this.Controls.Add(this.txtTelefoneGer);
            this.Controls.Add(this.txtEmailGer);
            this.Controls.Add(this.txtCPFGer);
            this.Controls.Add(this.txtDataNascGer);
            this.Controls.Add(this.txtNomeGer);
            this.Controls.Add(this.txtIDGer);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_gerente";
            this.Text = "frm_gerente";
            this.Load += new System.EventHandler(this.frm_gerente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemGer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtIDGer;
        private System.Windows.Forms.TextBox txtNomeGer;
        private System.Windows.Forms.TextBox txtDataNascGer;
        private System.Windows.Forms.TextBox txtCPFGer;
        private System.Windows.Forms.TextBox txtEmailGer;
        private System.Windows.Forms.TextBox txtTelefoneGer;
        private System.Windows.Forms.TextBox txtSalarioGer;
        private System.Windows.Forms.ComboBox cmbStatusGer;
        private System.Windows.Forms.PictureBox pic_imagemGer;
        private System.Windows.Forms.Button btn_CadastrarGer;
        private System.Windows.Forms.Button btn_AlterarGer;
        private System.Windows.Forms.Button btn_BuscarGer;
        private System.Windows.Forms.Button btn_ExcluirGer;
        private System.Windows.Forms.Button btnCarregarImagemGer;
    }
}