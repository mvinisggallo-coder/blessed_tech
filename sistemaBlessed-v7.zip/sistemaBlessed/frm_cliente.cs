﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_cliente : Form
    {
        public frm_cliente()
        {
            InitializeComponent();
        }

        private void CarregarResponsaveis()
        {
            try
            {
                using (SqlConnection conexao =
                    conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"
                SELECT
                    IDGerente AS ID,
                    NomeGerente AS Nome,
                    'Gerente' AS Tipo
                FROM Gerentes
 
                UNION ALL
 
                SELECT
                    IDFunc AS ID,
                    NomeFunc AS Nome,
                    'Funcionario' AS Tipo
                FROM Funcionários
 
                ORDER BY Nome";

                    SqlDataAdapter adaptador =
                        new SqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();

                    adaptador.Fill(tabela);

                    // Exibe o nome
                    cmbResponsavelCliente.DisplayMember = "Nome";

                    // Armazena a linha selecionada
                    cmbResponsavelCliente.DataSource = tabela;

                    cmbResponsavelCliente.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                         "Erro ao carregar responsáveis: " + ex.Message);
            }
        }

        private void frm_cliente_Load(object sender, EventArgs e)
        {
            txtIDCli.ReadOnly = true;

            // Adiciona as opções ao ComboBox
            cmbTipoPessoaCli.Items.Clear();
            cmbTipoPessoaCli.Items.Add("Física");
            cmbTipoPessoaCli.Items.Add("Jurídica");

            // Impede que o usuário digite outras opções
            cmbTipoPessoaCli.DropDownStyle = ComboBoxStyle.DropDownList;

            // Seleciona Ativo como padrão
            cmbTipoPessoaCli.SelectedIndex = 0;

            cmbResponsavelCliente.DropDownStyle =
            ComboBoxStyle.DropDownList;

            CarregarResponsaveis();
        }

        private void LimparCampos()
        {
            
            txtNomeCli.Clear();
            txtTeleCli.Clear();
            txtEmailCli.Clear();
            txtCpfouCnpjCli.Clear();
            txtDataNascCli.Clear();
            txtCEPCli.Clear();
            txtCidadeCli.Clear();
            txtEstadoCli.Clear();
            txtRuaouAvenidaCli.Clear();
            txtNumeroCli.Clear();
            txtBairroCli.Clear();
            txtComplementoCli.Clear();

            // Volta o status para Ativo
            cmbTipoPessoaCli.SelectedIndex = 0;


            // Posiciona o cursor no nome
            txtNomeCli.Focus();
        }

        private void btnCadastrarCli_Click(object sender, EventArgs e)
        {
            {
                {

                    try
                    {
                        using (SqlConnection conexao = conexao_banco.CriarConexao())
                        {
                            conexao.Open();

                            if (cmbResponsavelCliente.SelectedIndex == -1)
                            {
                                MessageBox.Show("Selecione um responsável!");
                                return;
                            }

                            DataRowView selecionado =
                                (DataRowView)cmbResponsavelCliente.SelectedItem;

                            int idResponsavel =
                                Convert.ToInt32(selecionado["ID"]);

                            string tipoResponsavel =
                                selecionado["Tipo"].ToString();

                            string sql = "INSERT INTO Clientes (NomeCliente, CPF, DataNasc, TipoPessoa, Telefone, Email, CEP, Cidade, Estado, RuaOuAvenida, Numero, Bairro, Complemento)" +
                                "VALUES (@NomeCliente, @CPF, @DataNasc, @TipoPessoa, @Telefone, @Email, @CEP, @Cidade, @Estado, @RuaOuAvenida, @Numero, @Bairro, @Complemento)";

                            using (SqlCommand comando = new SqlCommand(sql, conexao))
                            {
                                comando.Parameters.AddWithValue("@IDCliente", txtNomeCli.Text);                          
                                comando.Parameters.AddWithValue("@NomeCliente", txtNomeCli.Text);
                                comando.Parameters.AddWithValue("@CPF", txtCpfouCnpjCli.Text);
                                comando.Parameters.AddWithValue("@DataNasc", txtDataNascCli.Text);
                                comando.Parameters.AddWithValue("@TipoPessoa", cmbTipoPessoaCli.SelectedItem.ToString());
                                comando.Parameters.AddWithValue("@Telefone", txtTeleCli.Text);
                                comando.Parameters.AddWithValue("@Email", txtEmailCli.Text);
                                comando.Parameters.AddWithValue("@CEP", txtCEPCli.Text);
                                comando.Parameters.AddWithValue("@Cidade", txtCidadeCli.Text);
                                comando.Parameters.AddWithValue("@Estado", txtEstadoCli.Text);
                                comando.Parameters.AddWithValue("@RuaOuAvenida", txtRuaouAvenidaCli.Text);
                                comando.Parameters.AddWithValue("@Numero", txtNumeroCli.Text);
                                comando.Parameters.AddWithValue("@Bairro", txtBairroCli.Text);
                                comando.Parameters.AddWithValue("@Complemento", txtComplementoCli.Text);
                                comando.Parameters.AddWithValue(
                                 "@StatusFunc", cmbTipoPessoaCli.SelectedItem.ToString());

                                int linhasAfetadas = comando.ExecuteNonQuery();


                                if (linhasAfetadas > 0)
                                {
                                    MessageBox.Show("Cliente cadastrado com sucesso!");

                                    LimparCampos();
                                }

                            }

                        }

                        LimparCampos();

                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Erro ao cadastrar Cliente: " + ex.Message);
                    }
                }
            }
        }

        private void btnAlterarCli_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Verifica se existe um cliente carregado
                    if (txtNomeCli.Text == "")
                    {
                        MessageBox.Show("Busque um cliente antes de alterar.");
                        return;
                    }
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = "UPDATE Clientes SET NomeCliente=@NomeCliente, CPF=@CPF, DataNasc=@DataNasc, TipoPessoa=@TipoPessoa, Telefone=@Telefone, Email=@Email, CEP=@CEP, Cidade=@Cidade, Estado=@Estado, RuaOuAvenida=@RuaOuAvenida, Numero=@Numero, Bairro=@Bairro, Complemento=@Complemento WHERE IDCliente=@IDCliente";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@IDCliente", txtIDCli.Text);
                            comando.Parameters.AddWithValue("@NomeCliente", txtNomeCli.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCpfouCnpjCli.Text);
                            comando.Parameters.AddWithValue("@DataNasc", txtDataNascCli.Text);
                            comando.Parameters.AddWithValue("@TipoPessoa", cmbTipoPessoaCli.SelectedItem.ToString());
                            comando.Parameters.AddWithValue("@Telefone", txtTeleCli.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailCli.Text);
                            comando.Parameters.AddWithValue("@CEP", txtCEPCli.Text);
                            comando.Parameters.AddWithValue("@Cidade", txtCidadeCli.Text);
                            comando.Parameters.AddWithValue("@Estado", txtEstadoCli.Text);
                            comando.Parameters.AddWithValue("@RuaOuAvenida", txtRuaouAvenidaCli.Text);
                            comando.Parameters.AddWithValue("@Numero", txtNumeroCli.Text);
                            comando.Parameters.AddWithValue("@Bairro", txtBairroCli.Text);
                            comando.Parameters.AddWithValue("@Complemento", txtComplementoCli.Text);
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Cliente alterado com sucesso!");
                                LimparCampos();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao alterar cliente: " + ex.Message);
                }








            }

                }

        private void btnExcluirCli_Click(object sender, EventArgs e)
        {
            if (txtNomeCli.Text == "")
            {
                MessageBox.Show("Busque um cliente antes de excluir.");
                return;
            }

            DialogResult resposta = MessageBox.Show(
                "Tem certeza que deseja excluir este cliente?",
                "Confirmar exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta != DialogResult.Yes)
            {
                return;
            }
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "DELETE FROM Clientes WHERE IDCliente=@IDCliente";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@IDCliente", txtIDCli.Text);
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        if (linhasAfetadas > 0)
                        {
                            MessageBox.Show("Cliente excluído com sucesso!");
                            LimparCampos();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir cliente: " + ex.Message);
            }



            }

        private void btnBuscarCli_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeCli.Text == "")
                {
                    MessageBox.Show("Por favor, insira o nome do cliente para buscar.");
                    txtNomeCli.Focus();
                    return;
                }
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "SELECT * FROM Clientes WHERE NomeCliente LIKE @NomeCliente";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeCliente", "%" + txtNomeCli.Text + "%");
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtIDCli.Text = reader["IDCliente"].ToString();
                                txtNomeCli.Text = reader["NomeCliente"].ToString();
                                txtCpfouCnpjCli.Text = reader["CPF"].ToString();
                                txtDataNascCli.Text = reader["DataNasc"].ToString();
                                cmbTipoPessoaCli.SelectedItem = reader["TipoPessoa"].ToString();
                                txtTeleCli.Text = reader["Telefone"].ToString();
                                txtEmailCli.Text = reader["Email"].ToString();
                                txtCEPCli.Text = reader["CEP"].ToString();
                                txtCidadeCli.Text = reader["Cidade"].ToString();
                                txtEstadoCli.Text = reader["Estado"].ToString();
                                txtRuaouAvenidaCli.Text = reader["RuaOuAvenida"].ToString();
                                txtNumeroCli.Text = reader["Numero"].ToString();
                                txtBairroCli.Text = reader["Bairro"].ToString();
                                txtComplementoCli.Text = reader["Complemento"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Cliente não encontrado.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar cliente: " + ex.Message);
            }


            }
    }
}
























                    

                    
        

    
    


                    
            



























        
    
    
