﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_ordemServico : Form
    {
        public frm_ordemServico()
        {
            InitializeComponent();
        }

        private void frm_ordemServico_Load(object sender, EventArgs e)
        {

        }

        private void btnImprimirOS_Click(object sender, EventArgs e)
        {

        }

        private void btnAlterarOS_Click(object sender, EventArgs e)
        {

        }

        private void btnExcluirOS_Click(object sender, EventArgs e)
        {

        }
    }
}

