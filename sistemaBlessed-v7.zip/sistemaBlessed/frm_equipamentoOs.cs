﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_equipamentoOs : Form
    {
        public frm_equipamentoOs()
        {
            InitializeComponent();
        }



        private void CarregarCliente()

        {

            try

            {

                using (SqlConnection conexao =

                    conexao_banco.CriarConexao())

                {

                    conexao.Open();

                    string sql = @"SELECT

                            IDCliente,

                            NomeCliente

                           FROM Clientes

                           ORDER BY NomeCliente";

                    SqlDataAdapter adaptador =

                        new SqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();

                    adaptador.Fill(tabela);

                    // Exibe o nome do cliente

                    cmbResponsavelEquipa.DisplayMember = "NomeCliente";

                    // Armazena o ID do cliente

                    cmbResponsavelEquipa.ValueMember = "IDCliente";

                    // Carrega os dados

                    cmbResponsavelEquipa.DataSource = tabela;

                    // Inicia sem seleção

                    cmbResponsavelEquipa.SelectedIndex = -1;

                }

            }

            catch (Exception ex)

            {

                MessageBox.Show(

                    "Erro ao carregar clientes: " + ex.Message);

            }

        }
        

        private void LimparCampos()
        {
            
            txtNomeEquipa.Clear();
            txtGarantiaEquipa.Clear();
            txtCatEquipa.Clear();
            txtEstadoFisEquipa.Clear();
            txtMarcaEquipa.Clear();
            txtmodeloEquipa.Clear();
            txtNumeroSerieEquipa.Clear();
            txtSenhaSeFornecEquipa.Clear();
            txtCPF.Clear();
            cmbResponsavelEquipa.SelectedIndex = -1;

            txtNomeEquipa.Focus();
        }

        private void BuscarCPF()
        {
            try
            {
                // Verifica se existe um cliente selecionado
                if (cmbResponsavelEquipa.SelectedIndex == -1)
                    return;

                // Obtém o ID do cliente selecionado
                int idCliente = Convert.ToInt32(
                    cmbResponsavelEquipa.SelectedValue);

                using (SqlConnection conexao =
                    conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"
                SELECT CPF
                FROM Clientes
                WHERE IDCliente = @IDCliente";

                    using (SqlCommand comando =
                        new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue(
                            "@IDCliente", idCliente);

                        object resultado = comando.ExecuteScalar();

                        if (resultado != null &&
                            resultado != DBNull.Value)
                        {
                            txtCPF.Text = resultado.ToString();
                        }
                        else
                        {
                            txtCPF.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao buscar CPF: " + ex.Message);
            }
        }



















      

        private void frm_equipamentoOs_Load_1(object sender, EventArgs e)
        {
            txtIdEquipa.ReadOnly = true; // Impede que o usuário altere o ID do equipamento
            cmbResponsavelEquipa.DropDownStyle = ComboBoxStyle.DropDownList;
            LimparCampos();
            CarregarCliente();
        }

        private void cmbResponsavelEquipa_SelectedIndexChanged(object sender, EventArgs e)
        {
            BuscarCPF();
        }

        private void btnCadastrarEquipa_Click_1(object sender, EventArgs e)
        {

            {
                try
                {
                    if (cmbResponsavelEquipa.SelectedIndex == -1)
                    {
                        MessageBox.Show("Selecione um aluno!");
                        return;
                    }

                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        
                        conexao.Open();

                       
                     

                        string sql = @"INSERT INTO EquipamentosOS (IDCliente, NomeEquipamento, CatEquipa, GarantiaEquipa, NumeroSerieEquipa, MarcaEquipa,ModeloEquipa, EstadoFisicoEquipa, SenhaSeFornecEquipa, FotoEquipa)" +

                            "VALUES (@IDCliente, @NomeEquipamento, @CatEquipa, @GarantiaEquipa, @NumeroSerieEquipa, @MarcaEquipa, @ModeloEquipa, @EstadoFisicoEquipa, @SenhaSeFornecEquipa, @FotoEquipa";



                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {

                            comando.Parameters.AddWithValue("@IDCliente", cmbResponsavelEquipa.SelectedValue);
                           // comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                            comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                            comando.Parameters.AddWithValue("@CatEquipa", txtCatEquipa.Text);
                            comando.Parameters.AddWithValue("@GarantiaEquipa", txtGarantiaEquipa.Text);
                            comando.Parameters.AddWithValue("@NumeroSerieEquipa", txtNumeroSerieEquipa.Text);
                            comando.Parameters.AddWithValue("@MarcaEquipa", txtMarcaEquipa.Text);
                            comando.Parameters.AddWithValue("@ModeloEquipa", txtmodeloEquipa.Text);
                            comando.Parameters.AddWithValue("@EstadoFisicoEquipa", txtEstadoFisEquipa.Text);
                            comando.Parameters.AddWithValue("@SenhaSeFornecEquipa", txtSenhaSeFornecEquipa.Text);

                            comando.ExecuteNonQuery();

                            // PictureBox - Imagem
                            if (pic_imageEquipa.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imageEquipa.Image.Save(
                                        ms, System.Drawing.Imaging.ImageFormat.Png);

                                    byte[] imagemBytes = ms.ToArray();

                                    comando.Parameters.Add(
                                        "@FotoEquipa", SqlDbType.VarBinary, -1).Value =
                                        imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add(
                                    "@FotoEquipa", SqlDbType.VarBinary, -1).Value =
                                    DBNull.Value;
                            }













                            MessageBox.Show("Equipamento cadastrado com sucesso!");
                        }
                    }
                  
                    LimparCampos();
                }
                catch (Exception ex)
                {
                   
                    MessageBox.Show("Erro ao cadastrar equipamento:\n" + ex.Message);
                }
            }
        }
























        private void btnCarregarImagemEquipa_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pic_imageEquipa.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
        }

        private void btnAlterarEquipa_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Verifica se existe um equipamento carregado
                    if (txtNomeEquipa.Text == "")
                    {
                        MessageBox.Show("Busque um equipamento antes de alterar.");
                        return;
                    }
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = @"UPDATE EquipamentosOS SET 
                            IDCliente = @IDCliente,
                            NomeEquipamento = @NomeEquipamento,
                            CatEquipa = @CatEquipa,
                            GarantiaEquipa = @GarantiaEquipa,
                            NumeroSerieEquipa = @NumeroSerieEquipa,
                            MarcaEquipa = @MarcaEquipa,
                            ModeloEquipa = @ModeloEquipa,
                            EstadoFisicoEquipa = @EstadoFisicoEquipa,
                            SenhaSeFornecEquipa = @SenhaSeFornecEquipa,
                            FotoEquipa = @FotoEquipa
                            WHERE IDEquipa = @IDEquipa";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@IDCliente", cmbResponsavelEquipa.SelectedValue);
                            comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                            comando.Parameters.AddWithValue("@CatEquipa", txtCatEquipa.Text);
                            comando.Parameters.AddWithValue("@GarantiaEquipa", txtGarantiaEquipa.Text);
                            comando.Parameters.AddWithValue("@NumeroSerieEquipa", txtNumeroSerieEquipa.Text);
                            comando.Parameters.AddWithValue("@MarcaEquipa", txtMarcaEquipa.Text);
                            comando.Parameters.AddWithValue("@ModeloEquipa", txtmodeloEquipa.Text);
                            comando.Parameters.AddWithValue("@EstadoFisicoEquipa", txtEstadoFisEquipa.Text);
                            comando.Parameters.AddWithValue("@SenhaSeFornecEquipa", txtSenhaSeFornecEquipa.Text);
                            // PictureBox - Imagem
                            if (pic_imageEquipa.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imageEquipa.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                                    byte[] imagemBytes = ms.ToArray();
                                    comando.Parameters.Add("@FotoEquipa", SqlDbType.VarBinary, -1).Value = imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add("@FotoEquipa", SqlDbType.VarBinary, -1).Value = DBNull.Value;
                            }
                            comando.Parameters.AddWithValue("@IDEquipa", Convert.ToInt32(txtIdEquipa.Text));
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Equipamento alterado com sucesso!");
                            }
                            else
                            {
                                MessageBox.Show("Erro ao alterar equipamento.");

                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao alterar equipamento:\n" + ex.Message);
                }


            }
        }

        private void btnExcluirEquipa_Click(object sender, EventArgs e)
        {
            if (txtNomeEquipa.Text == "")
            {
                MessageBox.Show("Busque um equipamento antes de excluir.");
                return;
            }

            DialogResult resposta = MessageBox.Show(
                "Tem certeza que deseja excluir este equipamento?",
                "Confirmar exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta != DialogResult.Yes)
            {
                return;
            }
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = @"DELETE FROM EquipamentosOS WHERE IDEquipa = @IDEquipa";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@IDEquipa", Convert.ToInt32(txtIdEquipa.Text));
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        if (linhasAfetadas > 0)
                        {
                            MessageBox.Show("Equipamento excluído com sucesso!");
                            LimparCampos();
                        }
                        else
                        {
                            MessageBox.Show("Erro ao excluir equipamento.");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir equipamento:\n" + ex.Message);


            }
        }

        private void btnBuscarEquipa_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeEquipa.Text == "")
                {
                    MessageBox.Show("Por favor, insira o nome do equipamento para buscar.");
                    txtNomeEquipa.Focus();
                    return;
                }
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = @"SELECT * FROM EquipamentosOS WHERE NomeEquipamento = @NomeEquipamento";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtIdEquipa.Text = reader["IDEquipa"].ToString();
                                cmbResponsavelEquipa.SelectedValue = reader["IDCliente"];
                                txtCatEquipa.Text = reader["CatEquipa"].ToString();
                                txtGarantiaEquipa.Text = reader["GarantiaEquipa"].ToString();
                                txtNumeroSerieEquipa.Text = reader["NumeroSerieEquipa"].ToString();
                                txtMarcaEquipa.Text = reader["MarcaEquipa"].ToString();
                                txtmodeloEquipa.Text = reader["ModeloEquipa"].ToString();
                                txtEstadoFisEquipa.Text = reader["EstadoFisicoEquipa"].ToString();
                                txtSenhaSeFornecEquipa.Text = reader["SenhaSeFornecEquipa"].ToString();
                                // Carregar imagem
                                if (reader["FotoEquipa"] != DBNull.Value)
                                {
                                    byte[] imagemBytes = (byte[])reader["FotoEquipa"];
                                    using (MemoryStream ms = new MemoryStream(imagemBytes))
                                    {
                                        pic_imageEquipa.Image = Image.FromStream(ms);
                                    }
                                }
                                else
                                {
                                    pic_imageEquipa.Image = null;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Equipamento não encontrado.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar equipamento:\n" + ex.Message);
            }

            }
    }
    }

