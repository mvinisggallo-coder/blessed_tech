﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_funcionario : Form
    {
        public frm_funcionario()
        {
            InitializeComponent();
        }

        private void frm_funcionario_Load(object sender, EventArgs e)
        {
            txtIdFunc.ReadOnly = true;
        }
        private void LimparCampos()
        {
            txtNomeFunc.Clear();
            txtTeleFunc.Clear();
            txtEmailFunc.Clear();
            txtCPFFunc.Clear();
            txtSalarioFunc.Clear();

            // Volta o status para Ativo
            cmbStatusFunc.SelectedIndex = 0;

            // Remove a imagem
            Image imagemAnterior = pic_imageFunc.Image;
            pic_imageFunc.Image = null;
            imagemAnterior?.Dispose();

            // Posiciona o cursor no nome
            txtNomeFunc.Focus();

        }

        private void btnCadastrarFunc_Click(object sender, EventArgs e)
        {
            {

                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO Funcionários (NomeFunc, CPF, Telefone, Email, Salario, Cargo, Imagem, StatusFunc)" +
                            "VALUES (@NomeFunc, @CPF, @Telefone, @Email, @Salario, @Cargo, @Imagem,  @StatusFunc)";

                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeFunc", txtNomeFunc.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCPFFunc.Text);
                            comando.Parameters.AddWithValue("@Telefone", txtTeleFunc.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailFunc.Text);
                            comando.Parameters.AddWithValue("@Salario", txtSalarioFunc.Text);

                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusFunc", cmbStatusFunc.SelectedItem.ToString());

                            // ComboBox - Cargo
                            comando.Parameters.AddWithValue(
                                "@Cargo", cmbCargoFunc.SelectedItem.ToString());


                            // PictureBox - Imagem
                            if (pic_imageFunc.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imageFunc.Image.Save(
                                        ms, System.Drawing.Imaging.ImageFormat.Png);

                                    byte[] imagemBytes = ms.ToArray();

                                    comando.Parameters.Add(
                                        "@Imagem", SqlDbType.VarBinary, -1).Value =
                                        imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add(
                                    "@Imagem", SqlDbType.VarBinary, -1).Value =
                                    DBNull.Value;
                            }


                            int linhasAfetadas = comando.ExecuteNonQuery();


                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Funcionário cadastrado com sucesso!");

                                LimparCampos();
                            }

                        }

                    }

                    LimparCampos();

                }
                catch (Exception ex)
                {

                    MessageBox.Show("Erro ao cadastrar Funcionário: " + ex.Message);
                }
            }





































        }

        private void btnCarregarImagemFunc_Click(object sender, EventArgs e)
        {
            // Abre a janela para selecionar uma imagem
            using (OpenFileDialog abrir = new OpenFileDialog())
            {
                // Permite selecionar apenas imagens
                abrir.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp";

                // Abre a janela de seleção
                if (abrir.ShowDialog() == DialogResult.OK)
                {
                    // Carrega a imagem sem manter o arquivo bloqueado
                    byte[] bytes = System.IO.File.ReadAllBytes(abrir.FileName);

                    using (MemoryStream ms = new MemoryStream(bytes))
                    using (Image imagem = Image.FromStream(ms))
                    {
                        Image imagemAnterior = pic_imageFunc.Image;

                        pic_imageFunc.Image = new Bitmap(imagem);

                        imagemAnterior?.Dispose();
                    }
                }
            }
        }

        private void btnAlterarFunc_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Verifica se existe um equipamento carregado
                    if (txtNomeFunc.Text == "")
                    {
                        MessageBox.Show("Busque um funcionário antes de alterar.");
                        return;
                    }
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = "UPDATE Funcionários SET NomeFunc=@NomeFunc, CPF=@CPF, Telefone=@Telefone, Email=@Email, Salario=@Salario, Cargo=@Cargo, StatusFunc=@StatusFunc WHERE IdFunc=@IdFunc";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeFunc", txtNomeFunc.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCPFFunc.Text);
                            comando.Parameters.AddWithValue("@Telefone", txtTeleFunc.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailFunc.Text);
                            comando.Parameters.AddWithValue("@Salario", txtSalarioFunc.Text);
                            comando.Parameters.AddWithValue("@Cargo", cmbCargoFunc.SelectedItem.ToString());
                            
                            comando.Parameters.AddWithValue("@IdFunc", txtIdFunc.Text);
                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusFunc", cmbStatusFunc.SelectedItem.ToString());
                            // PictureBox - Imagem
                            if (pic_imageFunc.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imageFunc.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                                    byte[] imagemBytes = ms.ToArray();
                                    comando.Parameters.Add("@Imagem", SqlDbType.VarBinary, -1).Value = imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add("@Imagem", SqlDbType.VarBinary, -1).Value = DBNull.Value;
                            }
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Funcionário alterado com sucesso!");
                                LimparCampos();
                            }



                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao alterar funcionário: " + ex.Message);
                }
            }
        }

        private void btnExcluirFunc_Click(object sender, EventArgs e)
        {
            if (txtNomeFunc.Text == "")
            {
                MessageBox.Show("Busque um funcionário antes de excluir.");
                return;
            }

            DialogResult resposta = MessageBox.Show(
                "Tem certeza que deseja excluir este funcionário?",
                "Confirmar exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta != DialogResult.Yes)
            {
                return;
            }
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "DELETE FROM Funcionários WHERE IdFunc=@IdFunc";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@IdFunc", txtIdFunc.Text);
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        if (linhasAfetadas > 0)
                        {
                            MessageBox.Show("Funcionário excluído com sucesso!");
                            LimparCampos();
                        }
                        else
                        {
                            MessageBox.Show("Funcionário não encontrado ou já excluído.");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir funcionário: " + ex.Message);
            }
        }

        private void btnBuscarFunc_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeFunc.Text == "")
                {
                    MessageBox.Show("Por favor, insira o nome do funcionário para buscar.");
                    txtNomeFunc.Focus();
                    return;
                }
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "SELECT * FROM Funcionários WHERE NomeFunc LIKE @NomeFunc";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeFunc", "%" + txtNomeFunc.Text + "%");
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtIdFunc.Text = reader["IdFunc"].ToString();
                                txtCPFFunc.Text = reader["CPF"].ToString();
                                txtTeleFunc.Text = reader["Telefone"].ToString();
                                txtEmailFunc.Text = reader["Email"].ToString();
                                txtSalarioFunc.Text = reader["Salario"].ToString();
                                cmbCargoFunc.SelectedItem = reader["Cargo"].ToString();
                                cmbStatusFunc.SelectedItem = reader["StatusFunc"].ToString();
                                // Carregar a imagem
                                if (reader["Imagem"] != DBNull.Value)
                                {
                                    byte[] imagemBytes = (byte[])reader["Imagem"];
                                    using (MemoryStream ms = new MemoryStream(imagemBytes))
                                    {
                                        pic_imageFunc.Image = Image.FromStream(ms);
                                    }
                                }
                                else
                                {
                                    pic_imageFunc.Image = null;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Funcionário não encontrado.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar funcionário: " + ex.Message);


            }
        }
    }
}

