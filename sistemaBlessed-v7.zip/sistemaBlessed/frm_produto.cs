﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_produto : Form
    {
        public frm_produto()
        {
            InitializeComponent();
        }

        private void frm_produto_Load(object sender, EventArgs e)
        {
            txtIdProd.ReadOnly = true; // Impede que o usuário altere o ID do produto
        }
        private void LimparCampos()
        {
            txtNomeProd.Clear();
            txtDescProd.Clear();
            txtValorUnitProd.Clear();
            txtCatProd.Clear();
            txtCodBarrasProd.Clear();
            txtDataValidadeProd.Clear();
            txtMarcaProd.Clear();
            txtPesoProd.Clear();

            Image imagemAnterior = pic_imageProd.Image;
            pic_imageProd.Image = null;
            imagemAnterior?.Dispose();

            txtNomeProd.Focus();
        }
































        private void btnCadastrarProd_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO produtos (nomeProduto, descricao, valorUnitario,CategoriaProduto,DataValidadeouGarantia, Peso, Marca, CodigodeBarras)" +
                                     "VALUES (@nomeProduto, @descricao, @valorUnitario, @CategoriaProduto, @DataValidadeouGarantia, @Peso, @Marca, @CodigodeBarras)";


                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@nomeProduto", txtNomeProd.Text);
                            comando.Parameters.AddWithValue("@descricao", txtDescProd.Text);
                            comando.Parameters.AddWithValue("@valorUnitario", txtValorUnitProd.Text);
                            comando.Parameters.AddWithValue("@CategoriaProduto", txtCatProd.Text);
                            comando.Parameters.AddWithValue("@DataValidadeouGarantia", txtDataValidadeProd.Text);
                            comando.Parameters.AddWithValue("@Peso", txtPesoProd.Text);
                            comando.Parameters.AddWithValue("@Marca", txtMarcaProd.Text);
                            comando.Parameters.AddWithValue("@CodigodeBarras", txtCodBarrasProd.Text);
                            comando.ExecuteNonQuery();
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Produto cadastrado com sucesso!");
                                LimparCampos();
                            }
                            else
                            {
                                MessageBox.Show("Falha ao cadastrar o produto.");
                            }
                        }
                    }

                }

                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar o produto: " + ex.Message);
                }
            }
        }

        private void btnCarregarImagemProd_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Image imagemAnterior = pic_imageProd.Image;
                    pic_imageProd.Image = Image.FromFile(openFileDialog.FileName);
                    imagemAnterior?.Dispose();
                }
            }
        }

        private void btnBuscarProd_Click(object sender, EventArgs e)
        {
            try
            {
                // Verifica se o usuário informou o patrimônio
                if (txtNomeProd.Text == "")
                {
                    MessageBox.Show("Informe o nome do produto.");
                    txtIdProd.Focus();
                    return;
                }

                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "SELECT * FROM produtos WHERE nomeProduto = @NomeProduto";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeProduto", txtNomeProd.Text);
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtNomeProd.Text = reader["nomeProduto"].ToString();
                                txtDescProd.Text = reader["descricao"].ToString();
                                txtValorUnitProd.Text = reader["valorUnitario"].ToString();
                                txtCatProd.Text = reader["CategoriaProduto"].ToString();
                                txtDataValidadeProd.Text = reader["DataValidadeouGarantia"].ToString();
                                txtPesoProd.Text = reader["Peso"].ToString();
                                txtMarcaProd.Text = reader["Marca"].ToString();
                                txtCodBarrasProd.Text = reader["CodigodeBarras"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Produto não encontrado.");
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar o produto: " + ex.Message);

            }
        }

        private void btnAlterarProd_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Verifica se existe um equipamento carregado
                    if (txtNomeProd.Text == "")
                    {
                        MessageBox.Show("Busque um produto antes de alterar.");
                        return;
                    }
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = "UPDATE produtos SET descricao = @descricao, valorUnitario = @valorUnitario, CategoriaProduto = @CategoriaProduto, DataValidadeouGarantia = @DataValidadeouGarantia, Peso = @Peso, Marca = @Marca, CodigodeBarras = @CodigodeBarras WHERE nomeProduto = @nomeProduto";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@nomeProduto", txtNomeProd.Text);
                            comando.Parameters.AddWithValue("@descricao", txtDescProd.Text);
                            comando.Parameters.AddWithValue("@valorUnitario", decimal.Parse(txtValorUnitProd.Text));
                            comando.Parameters.AddWithValue("@CategoriaProduto", txtCatProd.Text);
                            comando.Parameters.AddWithValue("@DataValidadeouGarantia", txtDataValidadeProd.Text);
                            comando.Parameters.AddWithValue("@Peso", decimal.Parse(txtPesoProd.Text));
                            comando.Parameters.AddWithValue("@Marca", txtMarcaProd.Text);
                            comando.Parameters.AddWithValue("@CodigodeBarras", txtCodBarrasProd.Text);
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Produto alterado com sucesso!");
                                LimparCampos();
                            }
                            else
                            {
                                MessageBox.Show("Falha ao alterar o produto.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao alterar o produto: " + ex.Message);
                }
            }
        }

        private void btnExcluirProd_Click(object sender, EventArgs e)
        {
            if (txtNomeProd.Text == "")
            {
                MessageBox.Show("Busque um produto antes de excluir.");
                return;
            }

            DialogResult resposta = MessageBox.Show(
                "Tem certeza que deseja excluir este produto?",
                "Confirmar exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (SqlConnection conexao =
                    conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = "DELETE FROM produtos WHERE nomeProduto = @nomeProduto";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@nomeProduto", txtNomeProd.Text);
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        if (linhasAfetadas > 0)
                        {
                            MessageBox.Show("Produto excluído com sucesso!");
                            LimparCampos();
                        }
                        else
                        {
                            MessageBox.Show("Falha ao excluir o produto.");
                        }
                    }



                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir o produto: " + ex.Message);
            }
       }
    } }


