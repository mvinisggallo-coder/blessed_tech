﻿namespace sistemaBlessed
{
    partial class frm_produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pic_imageProd = new System.Windows.Forms.PictureBox();
            this.btnCadastrarProd = new System.Windows.Forms.Button();
            this.btnBuscarProd = new System.Windows.Forms.Button();
            this.btnExcluirProd = new System.Windows.Forms.Button();
            this.btnAlterarProd = new System.Windows.Forms.Button();
            this.btnCarregarImagemProd = new System.Windows.Forms.Button();
            this.txtIdProd = new System.Windows.Forms.TextBox();
            this.txtNomeProd = new System.Windows.Forms.TextBox();
            this.txtDataValidadeProd = new System.Windows.Forms.TextBox();
            this.txtPesoProd = new System.Windows.Forms.TextBox();
            this.txtCatProd = new System.Windows.Forms.TextBox();
            this.txtMarcaProd = new System.Windows.Forms.TextBox();
            this.txtCodBarrasProd = new System.Windows.Forms.TextBox();
            this.txtDescProd = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtValorUnitProd = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageProd)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(30, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(563, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de Produtos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(540, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Peso";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(715, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(191, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Imagem do Produto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label5.Location = new System.Drawing.Point(253, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Marca";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(37, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(255, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "Data de Validade / Garantia";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(323, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 24);
            this.label8.TabIndex = 6;
            this.label8.Text = "Categoria";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label9.Location = new System.Drawing.Point(38, 383);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "Descrição";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(37, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 24);
            this.label10.TabIndex = 8;
            this.label10.Text = "Código de Barras";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(38, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label11.Location = new System.Drawing.Point(37, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 24);
            this.label11.TabIndex = 11;
            this.label11.Text = "Nome";
            // 
            // pic_imageProd
            // 
            this.pic_imageProd.Location = new System.Drawing.Point(657, 204);
            this.pic_imageProd.Name = "pic_imageProd";
            this.pic_imageProd.Size = new System.Drawing.Size(297, 233);
            this.pic_imageProd.TabIndex = 12;
            this.pic_imageProd.TabStop = false;
            // 
            // btnCadastrarProd
            // 
            this.btnCadastrarProd.Location = new System.Drawing.Point(569, 499);
            this.btnCadastrarProd.Name = "btnCadastrarProd";
            this.btnCadastrarProd.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarProd.TabIndex = 27;
            this.btnCadastrarProd.Text = "Cadastrar";
            this.btnCadastrarProd.UseVisualStyleBackColor = true;
            this.btnCadastrarProd.Click += new System.EventHandler(this.btnCadastrarProd_Click);
            // 
            // btnBuscarProd
            // 
            this.btnBuscarProd.Location = new System.Drawing.Point(879, 499);
            this.btnBuscarProd.Name = "btnBuscarProd";
            this.btnBuscarProd.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarProd.TabIndex = 26;
            this.btnBuscarProd.Text = "Buscar";
            this.btnBuscarProd.UseVisualStyleBackColor = true;
            this.btnBuscarProd.Click += new System.EventHandler(this.btnBuscarProd_Click);
            // 
            // btnExcluirProd
            // 
            this.btnExcluirProd.Location = new System.Drawing.Point(777, 499);
            this.btnExcluirProd.Name = "btnExcluirProd";
            this.btnExcluirProd.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirProd.TabIndex = 25;
            this.btnExcluirProd.Text = "Excluir";
            this.btnExcluirProd.UseVisualStyleBackColor = true;
            this.btnExcluirProd.Click += new System.EventHandler(this.btnExcluirProd_Click);
            // 
            // btnAlterarProd
            // 
            this.btnAlterarProd.Location = new System.Drawing.Point(673, 499);
            this.btnAlterarProd.Name = "btnAlterarProd";
            this.btnAlterarProd.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarProd.TabIndex = 24;
            this.btnAlterarProd.Text = "Alterar";
            this.btnAlterarProd.UseVisualStyleBackColor = true;
            this.btnAlterarProd.Click += new System.EventHandler(this.btnAlterarProd_Click);
            // 
            // btnCarregarImagemProd
            // 
            this.btnCarregarImagemProd.Location = new System.Drawing.Point(751, 443);
            this.btnCarregarImagemProd.Name = "btnCarregarImagemProd";
            this.btnCarregarImagemProd.Size = new System.Drawing.Size(116, 23);
            this.btnCarregarImagemProd.TabIndex = 28;
            this.btnCarregarImagemProd.Text = "Carregar Imagem";
            this.btnCarregarImagemProd.UseVisualStyleBackColor = true;
            this.btnCarregarImagemProd.Click += new System.EventHandler(this.btnCarregarImagemProd_Click);
            // 
            // txtIdProd
            // 
            this.txtIdProd.Location = new System.Drawing.Point(68, 94);
            this.txtIdProd.Name = "txtIdProd";
            this.txtIdProd.Size = new System.Drawing.Size(100, 20);
            this.txtIdProd.TabIndex = 29;
            // 
            // txtNomeProd
            // 
            this.txtNomeProd.Location = new System.Drawing.Point(41, 165);
            this.txtNomeProd.Name = "txtNomeProd";
            this.txtNomeProd.Size = new System.Drawing.Size(471, 20);
            this.txtNomeProd.TabIndex = 30;
            // 
            // txtDataValidadeProd
            // 
            this.txtDataValidadeProd.Location = new System.Drawing.Point(41, 288);
            this.txtDataValidadeProd.Name = "txtDataValidadeProd";
            this.txtDataValidadeProd.Size = new System.Drawing.Size(100, 20);
            this.txtDataValidadeProd.TabIndex = 31;
            // 
            // txtPesoProd
            // 
            this.txtPesoProd.Location = new System.Drawing.Point(544, 165);
            this.txtPesoProd.Name = "txtPesoProd";
            this.txtPesoProd.Size = new System.Drawing.Size(72, 20);
            this.txtPesoProd.TabIndex = 32;
            // 
            // txtCatProd
            // 
            this.txtCatProd.Location = new System.Drawing.Point(327, 288);
            this.txtCatProd.Name = "txtCatProd";
            this.txtCatProd.Size = new System.Drawing.Size(154, 20);
            this.txtCatProd.TabIndex = 33;
            // 
            // txtMarcaProd
            // 
            this.txtMarcaProd.Location = new System.Drawing.Point(257, 231);
            this.txtMarcaProd.Name = "txtMarcaProd";
            this.txtMarcaProd.Size = new System.Drawing.Size(206, 20);
            this.txtMarcaProd.TabIndex = 34;
            // 
            // txtCodBarrasProd
            // 
            this.txtCodBarrasProd.Location = new System.Drawing.Point(41, 231);
            this.txtCodBarrasProd.Name = "txtCodBarrasProd";
            this.txtCodBarrasProd.Size = new System.Drawing.Size(178, 20);
            this.txtCodBarrasProd.TabIndex = 35;
            // 
            // txtDescProd
            // 
            this.txtDescProd.Location = new System.Drawing.Point(42, 410);
            this.txtDescProd.Multiline = true;
            this.txtDescProd.Name = "txtDescProd";
            this.txtDescProd.Size = new System.Drawing.Size(574, 72);
            this.txtDescProd.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label6.Location = new System.Drawing.Point(38, 321);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 24);
            this.label6.TabIndex = 37;
            this.label6.Text = "Valor Unitário (R$)";
            // 
            // txtValorUnitProd
            // 
            this.txtValorUnitProd.Location = new System.Drawing.Point(42, 348);
            this.txtValorUnitProd.Name = "txtValorUnitProd";
            this.txtValorUnitProd.Size = new System.Drawing.Size(72, 20);
            this.txtValorUnitProd.TabIndex = 38;
            // 
            // frm_produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 558);
            this.Controls.Add(this.txtValorUnitProd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDescProd);
            this.Controls.Add(this.txtCodBarrasProd);
            this.Controls.Add(this.txtMarcaProd);
            this.Controls.Add(this.txtCatProd);
            this.Controls.Add(this.txtPesoProd);
            this.Controls.Add(this.txtDataValidadeProd);
            this.Controls.Add(this.txtNomeProd);
            this.Controls.Add(this.txtIdProd);
            this.Controls.Add(this.btnCarregarImagemProd);
            this.Controls.Add(this.btnCadastrarProd);
            this.Controls.Add(this.btnBuscarProd);
            this.Controls.Add(this.btnExcluirProd);
            this.Controls.Add(this.btnAlterarProd);
            this.Controls.Add(this.pic_imageProd);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_produto";
            this.Text = "frm_produto";
            this.Load += new System.EventHandler(this.frm_produto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_imageProd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pic_imageProd;
        private System.Windows.Forms.Button btnCadastrarProd;
        private System.Windows.Forms.Button btnBuscarProd;
        private System.Windows.Forms.Button btnExcluirProd;
        private System.Windows.Forms.Button btnAlterarProd;
        private System.Windows.Forms.Button btnCarregarImagemProd;
        private System.Windows.Forms.TextBox txtIdProd;
        private System.Windows.Forms.TextBox txtNomeProd;
        private System.Windows.Forms.TextBox txtDataValidadeProd;
        private System.Windows.Forms.TextBox txtPesoProd;
        private System.Windows.Forms.TextBox txtCatProd;
        private System.Windows.Forms.TextBox txtMarcaProd;
        private System.Windows.Forms.TextBox txtCodBarrasProd;
        private System.Windows.Forms.TextBox txtDescProd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtValorUnitProd;
    }
}