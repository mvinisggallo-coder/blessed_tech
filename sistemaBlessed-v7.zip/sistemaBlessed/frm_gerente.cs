﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace sistemaBlessed
{
    public partial class frm_gerente : Form
    {
        public frm_gerente()
        {
            InitializeComponent();
        }

        private void frm_gerente_Load(object sender, EventArgs e)
        {
            txtIDGer.ReadOnly = true; // Impede que o usuário altere o ID do gerente

            // Adiciona as opções ao ComboBox
            cmbStatusGer.Items.Clear();
            cmbStatusGer.Items.Add("Ativo");
            cmbStatusGer.Items.Add("Inativo");

            // Impede que o usuário digite outras opções
            cmbStatusGer.DropDownStyle = ComboBoxStyle.DropDownList;

            // Seleciona Ativo como padrão
            cmbStatusGer.SelectedIndex = 0;

            // Ajusta a exibição da imagem
            pic_imagemGer.SizeMode = PictureBoxSizeMode.Zoom;
        }
        private void LimparCampos()
        {
            txtNomeGer.Clear();
            txtDataNascGer.Clear();
            txtTelefoneGer.Clear();
            txtEmailGer.Clear();
            txtCPFGer.Clear();
            txtSalarioGer.Clear();


            // Volta o status para Ativo
            cmbStatusGer.SelectedIndex = 0;

            // Remove a imagem
            Image imagemAnterior = pic_imagemGer.Image;
            pic_imagemGer.Image = null;
            imagemAnterior?.Dispose();

            // Posiciona o cursor no nome
            txtNomeGer.Focus();
        }

        private void btn_CadastrarGer_Click(object sender, EventArgs e)
        {
            {

                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                        string sql = "INSERT INTO Gerentes (NomeGerente, CPF, DataNasc, Telefone, Email, Salario, Imagem, StatusGerente)" +
                            "VALUES (@NomeGerente, @CPF, @DataNasc, @Telefone, @Email, @Salario, @Imagem, @StatusGerente)";

                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@NomeGerente", txtNomeGer.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCPFGer.Text);
                            comando.Parameters.AddWithValue("@DataNasc", txtDataNascGer.Text);
                            comando.Parameters.AddWithValue("@Telefone", txtTelefoneGer.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailGer.Text);
                            comando.Parameters.AddWithValue("@Salario", txtSalarioGer.Text);

                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusGerente", cmbStatusGer.SelectedItem.ToString());

                            // PictureBox - Imagem
                            if (pic_imagemGer.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imagemGer.Image.Save(
                                        ms, System.Drawing.Imaging.ImageFormat.Png);

                                    byte[] imagemBytes = ms.ToArray();

                                    comando.Parameters.Add(
                                        "@Imagem", SqlDbType.VarBinary, -1).Value =
                                        imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add(
                                    "@Imagem", SqlDbType.VarBinary, -1).Value =
                                    DBNull.Value;
                            }

                            int linhasAfetadas = comando.ExecuteNonQuery();

                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show(
                                    "Gerente cadastrado com sucesso!");

                                LimparCampos();
                            }

                        }

                    }

                }
                catch (Exception ex)
                {

                    MessageBox.Show("Erro ao cadastrar gerente: " + ex.Message);
                }
            }
        }

        private void btnCarregarImagemGer_Click(object sender, EventArgs e)
        {
            // Abre a janela para selecionar uma imagem
            using (OpenFileDialog abrir = new OpenFileDialog())
            {
                // Permite selecionar apenas imagens
                abrir.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp";

                // Abre a janela de seleção
                if (abrir.ShowDialog() == DialogResult.OK)
                {
                    // Carrega a imagem sem manter o arquivo bloqueado
                    byte[] bytes = System.IO.File.ReadAllBytes(abrir.FileName);

                    using (MemoryStream ms = new MemoryStream(bytes))
                    using (Image imagem = Image.FromStream(ms))
                    {
                        Image imagemAnterior = pic_imagemGer.Image;

                        pic_imagemGer.Image = new Bitmap(imagem);

                        imagemAnterior?.Dispose();
                    }
                }
            }
        }

        private void btn_AlterarGer_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Verifica se existe um equipamento carregado
                    if (txtNomeGer.Text == "")
                    {
                        MessageBox.Show("Busque um gerente antes de alterar.");
                        return;
                    }
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = "UPDATE Gerentes SET NomeGerente=@NomeGerente, CPF=@CPF, DataNasc=@DataNasc, Telefone=@Telefone, Email=@Email, Salario=@Salario, Imagem=@Imagem, StatusGerente=@StatusGerente WHERE IDGerente=@IDGerente";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            comando.Parameters.AddWithValue("@IDGerente", txtIDGer.Text);
                            comando.Parameters.AddWithValue("@NomeGerente", txtNomeGer.Text);
                            comando.Parameters.AddWithValue("@CPF", txtCPFGer.Text);
                            comando.Parameters.AddWithValue("@DataNasc", txtDataNascGer.Text);
                            comando.Parameters.AddWithValue("@Telefone", txtTelefoneGer.Text);
                            comando.Parameters.AddWithValue("@Email", txtEmailGer.Text);
                            comando.Parameters.AddWithValue("@Salario", txtSalarioGer.Text);
                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusGerente", cmbStatusGer.SelectedItem.ToString());
                            // PictureBox - Imagem
                            if (pic_imagemGer.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pic_imagemGer.Image.Save(
                                        ms, System.Drawing.Imaging.ImageFormat.Png);
                                    byte[] imagemBytes = ms.ToArray();
                                    comando.Parameters.Add(
                                        "@Imagem", SqlDbType.VarBinary, -1).Value =
                                        imagemBytes;
                                }
                            }
                            else
                            {
                                comando.Parameters.Add(
                                    "@Imagem", SqlDbType.VarBinary, -1).Value =
                                    DBNull.Value;
                            }
                            int linhasAfetadas = comando.ExecuteNonQuery();
                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show(
                                    "Gerente alterado com sucesso!");
                                LimparCampos();
                            }
                        }
                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao alterar gerente: " + ex.Message);

                }
            }
            }
        private void btn_ExcluirGer_Click(object sender, EventArgs e)
        {
            if (txtNomeGer.Text == "")
            {
                MessageBox.Show("Busque um gerente antes de excluir.");
                return;
            }

            DialogResult resposta = MessageBox.Show(
                "Tem certeza que deseja excluir este gerente?",
                "Confirmar exclusão",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resposta != DialogResult.Yes)
            {
                return;
            }
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "DELETE FROM Gerentes WHERE IDGerente=@IDGerente";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@IDGerente", txtIDGer.Text);
                        int linhasAfetadas = comando.ExecuteNonQuery();
                        if (linhasAfetadas > 0)
                        {
                            MessageBox.Show("Gerente excluído com sucesso!");
                            LimparCampos();
                        }
                        else
                        {
                            MessageBox.Show("Nenhum gerente encontrado para excluir.");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir gerente: " + ex.Message);
            }
        }

        private void btn_BuscarGer_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeGer.Text == "")
                {
                    MessageBox.Show("Por favor, insira o nome do gerente para buscar.");
                    txtNomeGer.Focus();
                    return;
                }

                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = "SELECT * FROM Gerentes WHERE NomeGerente LIKE @NomeGerente";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeGerente", "%" + txtNomeGer.Text + "%");
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtIDGer.Text = reader["IDGerente"].ToString();
                                txtCPFGer.Text = reader["CPF"].ToString();
                                txtDataNascGer.Text = reader["DataNasc"].ToString();
                                txtTelefoneGer.Text = reader["Telefone"].ToString();
                                txtEmailGer.Text = reader["Email"].ToString();
                                txtSalarioGer.Text = reader["Salario"].ToString();
                                // ComboBox - Status
                                string status = reader["StatusGerente"].ToString();
                                cmbStatusGer.SelectedItem = status;
                                // PictureBox - Imagem
                                if (reader["Imagem"] != DBNull.Value)
                                {
                                    byte[] imagemBytes = (byte[])reader["Imagem"];
                                    using (MemoryStream ms = new MemoryStream(imagemBytes))
                                    {
                                        Image imagemAnterior = pic_imagemGer.Image;
                                        pic_imagemGer.Image = new Bitmap(Image.FromStream(ms));
                                        imagemAnterior?.Dispose();
                                    }
                                }
                                else
                                {
                                    Image imagemAnterior = pic_imagemGer.Image;
                                    pic_imagemGer.Image = null;
                                    imagemAnterior?.Dispose();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Nenhum gerente encontrado com esse nome.");
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar gerente: " + ex.Message);
            }
        }
    }
}
            
        





                    

                
            
        
    

