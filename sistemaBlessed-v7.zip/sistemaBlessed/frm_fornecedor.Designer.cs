﻿namespace sistemaBlessed
{
    partial class frm_fornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtIdFor = new System.Windows.Forms.TextBox();
            this.txtNomeFor = new System.Windows.Forms.TextBox();
            this.txtRuaouAvenidaFor = new System.Windows.Forms.TextBox();
            this.txtInscricaoEstFor = new System.Windows.Forms.TextBox();
            this.cmbStatusFor = new System.Windows.Forms.ComboBox();
            this.txtCpfouCnpjFor = new System.Windows.Forms.TextBox();
            this.txtEmailFor = new System.Windows.Forms.TextBox();
            this.txtTeleFor = new System.Windows.Forms.TextBox();
            this.txtCidadeFor = new System.Windows.Forms.TextBox();
            this.txtCEPFor = new System.Windows.Forms.TextBox();
            this.txtEstadoFor = new System.Windows.Forms.TextBox();
            this.txtNumeroFor = new System.Windows.Forms.TextBox();
            this.txtBairroFor = new System.Windows.Forms.TextBox();
            this.txtComplementoFor = new System.Windows.Forms.TextBox();
            this.txtNacionaliFor = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.pic_imagemFor = new System.Windows.Forms.PictureBox();
            this.btnCarregarImagemFor = new System.Windows.Forms.Button();
            this.btnCadastrarFor = new System.Windows.Forms.Button();
            this.btnExcluirFor = new System.Windows.Forms.Button();
            this.btnAlterarFor = new System.Windows.Forms.Button();
            this.cmbTipoPessoaFor = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemFor)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(38, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(676, 69);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cadastro de Fornecedores";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(56, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 10;
            this.label10.Text = "ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label6.Location = new System.Drawing.Point(46, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nome";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label15.Location = new System.Drawing.Point(46, 324);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 24);
            this.label15.TabIndex = 15;
            this.label15.Text = "Tipo de pessoa";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label12.Location = new System.Drawing.Point(316, 440);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 24);
            this.label12.TabIndex = 16;
            this.label12.Text = "Rua / Avenida";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label5.Location = new System.Drawing.Point(241, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 24);
            this.label5.TabIndex = 17;
            this.label5.Text = "Número";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(208, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 24);
            this.label7.TabIndex = 18;
            this.label7.Text = "Bairro";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label16.Location = new System.Drawing.Point(209, 385);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 24);
            this.label16.TabIndex = 19;
            this.label16.Text = "Complemento";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(46, 385);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 24);
            this.label3.TabIndex = 20;
            this.label3.Text = "CPF / CNPJ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(49, 440);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 21;
            this.label8.Text = "Email";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label13.Location = new System.Drawing.Point(49, 493);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 24);
            this.label13.TabIndex = 22;
            this.label13.Text = "Telefone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(214, 495);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 24);
            this.label4.TabIndex = 23;
            this.label4.Text = "CEP";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label14.Location = new System.Drawing.Point(342, 495);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 24);
            this.label14.TabIndex = 24;
            this.label14.Text = "Cidade";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label9.Location = new System.Drawing.Point(500, 495);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 24);
            this.label9.TabIndex = 25;
            this.label9.Text = "Estado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(46, 552);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 24);
            this.label2.TabIndex = 26;
            this.label2.Text = "Nacionalidade";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label11.Location = new System.Drawing.Point(208, 552);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 24);
            this.label11.TabIndex = 27;
            this.label11.Text = "Status";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label17.Location = new System.Drawing.Point(46, 266);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(168, 24);
            this.label17.TabIndex = 28;
            this.label17.Text = "Inscrição Estadual";
            // 
            // txtIdFor
            // 
            this.txtIdFor.Location = new System.Drawing.Point(84, 103);
            this.txtIdFor.Name = "txtIdFor";
            this.txtIdFor.Size = new System.Drawing.Size(100, 20);
            this.txtIdFor.TabIndex = 29;
            // 
            // txtNomeFor
            // 
            this.txtNomeFor.Location = new System.Drawing.Point(48, 237);
            this.txtNomeFor.Name = "txtNomeFor";
            this.txtNomeFor.Size = new System.Drawing.Size(432, 20);
            this.txtNomeFor.TabIndex = 30;
            // 
            // txtRuaouAvenidaFor
            // 
            this.txtRuaouAvenidaFor.Location = new System.Drawing.Point(320, 467);
            this.txtRuaouAvenidaFor.Name = "txtRuaouAvenidaFor";
            this.txtRuaouAvenidaFor.Size = new System.Drawing.Size(279, 20);
            this.txtRuaouAvenidaFor.TabIndex = 31;
            // 
            // txtInscricaoEstFor
            // 
            this.txtInscricaoEstFor.Location = new System.Drawing.Point(48, 293);
            this.txtInscricaoEstFor.Name = "txtInscricaoEstFor";
            this.txtInscricaoEstFor.Size = new System.Drawing.Size(166, 20);
            this.txtInscricaoEstFor.TabIndex = 32;
            // 
            // cmbStatusFor
            // 
            this.cmbStatusFor.FormattingEnabled = true;
            this.cmbStatusFor.Items.AddRange(new object[] {
            "Ativo",
            "Não Ativo"});
            this.cmbStatusFor.Location = new System.Drawing.Point(205, 576);
            this.cmbStatusFor.Name = "cmbStatusFor";
            this.cmbStatusFor.Size = new System.Drawing.Size(114, 21);
            this.cmbStatusFor.TabIndex = 33;
            // 
            // txtCpfouCnpjFor
            // 
            this.txtCpfouCnpjFor.Location = new System.Drawing.Point(47, 412);
            this.txtCpfouCnpjFor.Name = "txtCpfouCnpjFor";
            this.txtCpfouCnpjFor.Size = new System.Drawing.Size(137, 20);
            this.txtCpfouCnpjFor.TabIndex = 34;
            // 
            // txtEmailFor
            // 
            this.txtEmailFor.Location = new System.Drawing.Point(47, 467);
            this.txtEmailFor.Name = "txtEmailFor";
            this.txtEmailFor.Size = new System.Drawing.Size(241, 20);
            this.txtEmailFor.TabIndex = 35;
            // 
            // txtTeleFor
            // 
            this.txtTeleFor.Location = new System.Drawing.Point(47, 520);
            this.txtTeleFor.Name = "txtTeleFor";
            this.txtTeleFor.Size = new System.Drawing.Size(137, 20);
            this.txtTeleFor.TabIndex = 36;
            // 
            // txtCidadeFor
            // 
            this.txtCidadeFor.Location = new System.Drawing.Point(343, 520);
            this.txtCidadeFor.Name = "txtCidadeFor";
            this.txtCidadeFor.Size = new System.Drawing.Size(137, 20);
            this.txtCidadeFor.TabIndex = 37;
            // 
            // txtCEPFor
            // 
            this.txtCEPFor.Location = new System.Drawing.Point(212, 520);
            this.txtCEPFor.Name = "txtCEPFor";
            this.txtCEPFor.Size = new System.Drawing.Size(107, 20);
            this.txtCEPFor.TabIndex = 38;
            // 
            // txtEstadoFor
            // 
            this.txtEstadoFor.Location = new System.Drawing.Point(503, 520);
            this.txtEstadoFor.Name = "txtEstadoFor";
            this.txtEstadoFor.Size = new System.Drawing.Size(100, 20);
            this.txtEstadoFor.TabIndex = 39;
            // 
            // txtNumeroFor
            // 
            this.txtNumeroFor.Location = new System.Drawing.Point(245, 293);
            this.txtNumeroFor.Name = "txtNumeroFor";
            this.txtNumeroFor.Size = new System.Drawing.Size(50, 20);
            this.txtNumeroFor.TabIndex = 40;
            // 
            // txtBairroFor
            // 
            this.txtBairroFor.Location = new System.Drawing.Point(212, 356);
            this.txtBairroFor.Name = "txtBairroFor";
            this.txtBairroFor.Size = new System.Drawing.Size(213, 20);
            this.txtBairroFor.TabIndex = 41;
            // 
            // txtComplementoFor
            // 
            this.txtComplementoFor.Location = new System.Drawing.Point(212, 412);
            this.txtComplementoFor.Name = "txtComplementoFor";
            this.txtComplementoFor.Size = new System.Drawing.Size(314, 20);
            this.txtComplementoFor.TabIndex = 42;
            // 
            // txtNacionaliFor
            // 
            this.txtNacionaliFor.Location = new System.Drawing.Point(47, 577);
            this.txtNacionaliFor.Name = "txtNacionaliFor";
            this.txtNacionaliFor.Size = new System.Drawing.Size(137, 20);
            this.txtNacionaliFor.TabIndex = 43;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label18.Location = new System.Drawing.Point(649, 209);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(221, 24);
            this.label18.TabIndex = 45;
            this.label18.Text = "Imagem do Fornecedor";
            // 
            // pic_imagemFor
            // 
            this.pic_imagemFor.Location = new System.Drawing.Point(640, 247);
            this.pic_imagemFor.Name = "pic_imagemFor";
            this.pic_imagemFor.Size = new System.Drawing.Size(241, 250);
            this.pic_imagemFor.TabIndex = 46;
            this.pic_imagemFor.TabStop = false;
            // 
            // btnCarregarImagemFor
            // 
            this.btnCarregarImagemFor.Location = new System.Drawing.Point(694, 504);
            this.btnCarregarImagemFor.Name = "btnCarregarImagemFor";
            this.btnCarregarImagemFor.Size = new System.Drawing.Size(116, 23);
            this.btnCarregarImagemFor.TabIndex = 47;
            this.btnCarregarImagemFor.Text = "Carregar Imagem";
            this.btnCarregarImagemFor.UseVisualStyleBackColor = true;
            this.btnCarregarImagemFor.Click += new System.EventHandler(this.btnCarregarImagemFor_Click);
            // 
            // btnCadastrarFor
            // 
            this.btnCadastrarFor.Location = new System.Drawing.Point(598, 577);
            this.btnCadastrarFor.Name = "btnCadastrarFor";
            this.btnCadastrarFor.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarFor.TabIndex = 51;
            this.btnCadastrarFor.Text = "Cadastrar";
            this.btnCadastrarFor.UseVisualStyleBackColor = true;
            this.btnCadastrarFor.Click += new System.EventHandler(this.btnCadastrarFor_Click);
            // 
            // btnExcluirFor
            // 
            this.btnExcluirFor.Location = new System.Drawing.Point(806, 577);
            this.btnExcluirFor.Name = "btnExcluirFor";
            this.btnExcluirFor.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirFor.TabIndex = 49;
            this.btnExcluirFor.Text = "Excluir";
            this.btnExcluirFor.UseVisualStyleBackColor = true;
            this.btnExcluirFor.Click += new System.EventHandler(this.btnExcluirFor_Click);
            // 
            // btnAlterarFor
            // 
            this.btnAlterarFor.Location = new System.Drawing.Point(702, 577);
            this.btnAlterarFor.Name = "btnAlterarFor";
            this.btnAlterarFor.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarFor.TabIndex = 48;
            this.btnAlterarFor.Text = "Alterar";
            this.btnAlterarFor.UseVisualStyleBackColor = true;
            this.btnAlterarFor.Click += new System.EventHandler(this.btnAlterarFor_Click);
            // 
            // cmbTipoPessoaFor
            // 
            this.cmbTipoPessoaFor.FormattingEnabled = true;
            this.cmbTipoPessoaFor.Location = new System.Drawing.Point(48, 351);
            this.cmbTipoPessoaFor.Name = "cmbTipoPessoaFor";
            this.cmbTipoPessoaFor.Size = new System.Drawing.Size(121, 21);
            this.cmbTipoPessoaFor.TabIndex = 52;
            // 
            // frm_fornecedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 644);
            this.Controls.Add(this.cmbTipoPessoaFor);
            this.Controls.Add(this.btnCadastrarFor);
            this.Controls.Add(this.btnExcluirFor);
            this.Controls.Add(this.btnAlterarFor);
            this.Controls.Add(this.btnCarregarImagemFor);
            this.Controls.Add(this.pic_imagemFor);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtNacionaliFor);
            this.Controls.Add(this.txtComplementoFor);
            this.Controls.Add(this.txtBairroFor);
            this.Controls.Add(this.txtNumeroFor);
            this.Controls.Add(this.txtEstadoFor);
            this.Controls.Add(this.txtCEPFor);
            this.Controls.Add(this.txtCidadeFor);
            this.Controls.Add(this.txtTeleFor);
            this.Controls.Add(this.txtEmailFor);
            this.Controls.Add(this.txtCpfouCnpjFor);
            this.Controls.Add(this.cmbStatusFor);
            this.Controls.Add(this.txtInscricaoEstFor);
            this.Controls.Add(this.txtRuaouAvenidaFor);
            this.Controls.Add(this.txtNomeFor);
            this.Controls.Add(this.txtIdFor);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Name = "frm_fornecedor";
            this.Text = "frm_fornecedor";
            this.Load += new System.EventHandler(this.frm_fornecedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemFor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtIdFor;
        private System.Windows.Forms.TextBox txtNomeFor;
        private System.Windows.Forms.TextBox txtRuaouAvenidaFor;
        private System.Windows.Forms.TextBox txtInscricaoEstFor;
        private System.Windows.Forms.ComboBox cmbStatusFor;
        private System.Windows.Forms.TextBox txtCpfouCnpjFor;
        private System.Windows.Forms.TextBox txtEmailFor;
        private System.Windows.Forms.TextBox txtTeleFor;
        private System.Windows.Forms.TextBox txtCidadeFor;
        private System.Windows.Forms.TextBox txtCEPFor;
        private System.Windows.Forms.TextBox txtEstadoFor;
        private System.Windows.Forms.TextBox txtNumeroFor;
        private System.Windows.Forms.TextBox txtBairroFor;
        private System.Windows.Forms.TextBox txtComplementoFor;
        private System.Windows.Forms.TextBox txtNacionaliFor;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pic_imagemFor;
        private System.Windows.Forms.Button btnCarregarImagemFor;
        private System.Windows.Forms.Button btnCadastrarFor;
        private System.Windows.Forms.Button btnExcluirFor;
        private System.Windows.Forms.Button btnAlterarFor;
        private System.Windows.Forms.ComboBox cmbTipoPessoaFor;
    }
}