﻿namespace sistemaBlessed
{
    partial class frm_cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtIDCli = new System.Windows.Forms.TextBox();
            this.txtNomeCli = new System.Windows.Forms.TextBox();
            this.txtDataNascCli = new System.Windows.Forms.TextBox();
            this.txtCpfouCnpjCli = new System.Windows.Forms.TextBox();
            this.txtEmailCli = new System.Windows.Forms.TextBox();
            this.txtCEPCli = new System.Windows.Forms.TextBox();
            this.txtTeleCli = new System.Windows.Forms.TextBox();
            this.txtCidadeCli = new System.Windows.Forms.TextBox();
            this.cmbTipoPessoaCli = new System.Windows.Forms.ComboBox();
            this.txtEstadoCli = new System.Windows.Forms.TextBox();
            this.txtRuaouAvenidaCli = new System.Windows.Forms.TextBox();
            this.txtNumeroCli = new System.Windows.Forms.TextBox();
            this.txtBairroCli = new System.Windows.Forms.TextBox();
            this.txtComplementoCli = new System.Windows.Forms.TextBox();
            this.btnCadastrarCli = new System.Windows.Forms.Button();
            this.btnAlterarCli = new System.Windows.Forms.Button();
            this.btnExcluirCli = new System.Windows.Forms.Button();
            this.btnBuscarCli = new System.Windows.Forms.Button();
            this.cmbResponsavelCliente = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(39, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(534, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de Clientes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(48, 372);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "CPF / CNPJ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(48, 549);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "CEP";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label5.Location = new System.Drawing.Point(511, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Número";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label6.Location = new System.Drawing.Point(48, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Nome";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(511, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Bairro";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(48, 430);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "Email";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label9.Location = new System.Drawing.Point(51, 649);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Estado";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(47, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label11.Location = new System.Drawing.Point(48, 265);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(192, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Data de Nascimento";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label12.Location = new System.Drawing.Point(511, 209);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "Rua / Avenida";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label13.Location = new System.Drawing.Point(48, 490);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "Telefone";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label14.Location = new System.Drawing.Point(48, 599);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "Cidade";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label15.Location = new System.Drawing.Point(48, 319);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 24);
            this.label15.TabIndex = 14;
            this.label15.Text = "Tipo de pessoa";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label16.Location = new System.Drawing.Point(511, 372);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 24);
            this.label16.TabIndex = 15;
            this.label16.Text = "Complemento";
            // 
            // txtIDCli
            // 
            this.txtIDCli.Location = new System.Drawing.Point(73, 91);
            this.txtIDCli.Name = "txtIDCli";
            this.txtIDCli.Size = new System.Drawing.Size(100, 20);
            this.txtIDCli.TabIndex = 16;
            // 
            // txtNomeCli
            // 
            this.txtNomeCli.Location = new System.Drawing.Point(52, 234);
            this.txtNomeCli.Name = "txtNomeCli";
            this.txtNomeCli.Size = new System.Drawing.Size(443, 20);
            this.txtNomeCli.TabIndex = 17;
            // 
            // txtDataNascCli
            // 
            this.txtDataNascCli.Location = new System.Drawing.Point(52, 292);
            this.txtDataNascCli.Name = "txtDataNascCli";
            this.txtDataNascCli.Size = new System.Drawing.Size(104, 20);
            this.txtDataNascCli.TabIndex = 18;
            // 
            // txtCpfouCnpjCli
            // 
            this.txtCpfouCnpjCli.Location = new System.Drawing.Point(51, 400);
            this.txtCpfouCnpjCli.Name = "txtCpfouCnpjCli";
            this.txtCpfouCnpjCli.Size = new System.Drawing.Size(143, 20);
            this.txtCpfouCnpjCli.TabIndex = 20;
            // 
            // txtEmailCli
            // 
            this.txtEmailCli.Location = new System.Drawing.Point(51, 457);
            this.txtEmailCli.Name = "txtEmailCli";
            this.txtEmailCli.Size = new System.Drawing.Size(234, 20);
            this.txtEmailCli.TabIndex = 21;
            // 
            // txtCEPCli
            // 
            this.txtCEPCli.Location = new System.Drawing.Point(51, 576);
            this.txtCEPCli.Name = "txtCEPCli";
            this.txtCEPCli.Size = new System.Drawing.Size(143, 20);
            this.txtCEPCli.TabIndex = 22;
            // 
            // txtTeleCli
            // 
            this.txtTeleCli.Location = new System.Drawing.Point(51, 517);
            this.txtTeleCli.Name = "txtTeleCli";
            this.txtTeleCli.Size = new System.Drawing.Size(189, 20);
            this.txtTeleCli.TabIndex = 23;
            // 
            // txtCidadeCli
            // 
            this.txtCidadeCli.Location = new System.Drawing.Point(51, 626);
            this.txtCidadeCli.Name = "txtCidadeCli";
            this.txtCidadeCli.Size = new System.Drawing.Size(143, 20);
            this.txtCidadeCli.TabIndex = 24;
            // 
            // cmbTipoPessoaCli
            // 
            this.cmbTipoPessoaCli.FormattingEnabled = true;
            this.cmbTipoPessoaCli.Items.AddRange(new object[] {
            "Física",
            "Jurídica"});
            this.cmbTipoPessoaCli.Location = new System.Drawing.Point(52, 346);
            this.cmbTipoPessoaCli.Name = "cmbTipoPessoaCli";
            this.cmbTipoPessoaCli.Size = new System.Drawing.Size(121, 21);
            this.cmbTipoPessoaCli.TabIndex = 25;
            // 
            // txtEstadoCli
            // 
            this.txtEstadoCli.Location = new System.Drawing.Point(51, 676);
            this.txtEstadoCli.Name = "txtEstadoCli";
            this.txtEstadoCli.Size = new System.Drawing.Size(201, 20);
            this.txtEstadoCli.TabIndex = 26;
            // 
            // txtRuaouAvenidaCli
            // 
            this.txtRuaouAvenidaCli.Location = new System.Drawing.Point(515, 234);
            this.txtRuaouAvenidaCli.Name = "txtRuaouAvenidaCli";
            this.txtRuaouAvenidaCli.Size = new System.Drawing.Size(268, 20);
            this.txtRuaouAvenidaCli.TabIndex = 27;
            // 
            // txtNumeroCli
            // 
            this.txtNumeroCli.Location = new System.Drawing.Point(515, 292);
            this.txtNumeroCli.Name = "txtNumeroCli";
            this.txtNumeroCli.Size = new System.Drawing.Size(59, 20);
            this.txtNumeroCli.TabIndex = 28;
            // 
            // txtBairroCli
            // 
            this.txtBairroCli.Location = new System.Drawing.Point(515, 349);
            this.txtBairroCli.Name = "txtBairroCli";
            this.txtBairroCli.Size = new System.Drawing.Size(214, 20);
            this.txtBairroCli.TabIndex = 29;
            // 
            // txtComplementoCli
            // 
            this.txtComplementoCli.Location = new System.Drawing.Point(515, 400);
            this.txtComplementoCli.Name = "txtComplementoCli";
            this.txtComplementoCli.Size = new System.Drawing.Size(306, 20);
            this.txtComplementoCli.TabIndex = 30;
            // 
            // btnCadastrarCli
            // 
            this.btnCadastrarCli.Location = new System.Drawing.Point(487, 673);
            this.btnCadastrarCli.Name = "btnCadastrarCli";
            this.btnCadastrarCli.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarCli.TabIndex = 31;
            this.btnCadastrarCli.Text = "Cadastrar";
            this.btnCadastrarCli.UseVisualStyleBackColor = true;
            this.btnCadastrarCli.Click += new System.EventHandler(this.btnCadastrarCli_Click);
            // 
            // btnAlterarCli
            // 
            this.btnAlterarCli.Location = new System.Drawing.Point(585, 673);
            this.btnAlterarCli.Name = "btnAlterarCli";
            this.btnAlterarCli.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarCli.TabIndex = 32;
            this.btnAlterarCli.Text = "Alterar";
            this.btnAlterarCli.UseVisualStyleBackColor = true;
            this.btnAlterarCli.Click += new System.EventHandler(this.btnAlterarCli_Click);
            // 
            // btnExcluirCli
            // 
            this.btnExcluirCli.Location = new System.Drawing.Point(680, 673);
            this.btnExcluirCli.Name = "btnExcluirCli";
            this.btnExcluirCli.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirCli.TabIndex = 33;
            this.btnExcluirCli.Text = "Excluir";
            this.btnExcluirCli.UseVisualStyleBackColor = true;
            this.btnExcluirCli.Click += new System.EventHandler(this.btnExcluirCli_Click);
            // 
            // btnBuscarCli
            // 
            this.btnBuscarCli.Location = new System.Drawing.Point(777, 673);
            this.btnBuscarCli.Name = "btnBuscarCli";
            this.btnBuscarCli.Size = new System.Drawing.Size(75, 23);
            this.btnBuscarCli.TabIndex = 34;
            this.btnBuscarCli.Text = "Buscar";
            this.btnBuscarCli.UseVisualStyleBackColor = true;
            this.btnBuscarCli.Click += new System.EventHandler(this.btnBuscarCli_Click);
            // 
            // cmbResponsavelCliente
            // 
            this.cmbResponsavelCliente.FormattingEnabled = true;
            this.cmbResponsavelCliente.Location = new System.Drawing.Point(525, 92);
            this.cmbResponsavelCliente.Name = "cmbResponsavelCliente";
            this.cmbResponsavelCliente.Size = new System.Drawing.Size(121, 21);
            this.cmbResponsavelCliente.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(286, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 24);
            this.label2.TabIndex = 36;
            this.label2.Text = "Responsável pelo Cliente";
            // 
            // frm_cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(899, 747);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbResponsavelCliente);
            this.Controls.Add(this.btnBuscarCli);
            this.Controls.Add(this.btnExcluirCli);
            this.Controls.Add(this.btnAlterarCli);
            this.Controls.Add(this.btnCadastrarCli);
            this.Controls.Add(this.txtComplementoCli);
            this.Controls.Add(this.txtBairroCli);
            this.Controls.Add(this.txtNumeroCli);
            this.Controls.Add(this.txtRuaouAvenidaCli);
            this.Controls.Add(this.txtEstadoCli);
            this.Controls.Add(this.cmbTipoPessoaCli);
            this.Controls.Add(this.txtCidadeCli);
            this.Controls.Add(this.txtTeleCli);
            this.Controls.Add(this.txtCEPCli);
            this.Controls.Add(this.txtEmailCli);
            this.Controls.Add(this.txtCpfouCnpjCli);
            this.Controls.Add(this.txtDataNascCli);
            this.Controls.Add(this.txtNomeCli);
            this.Controls.Add(this.txtIDCli);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "frm_cliente";
            this.Text = "frm_cliente";
            this.Load += new System.EventHandler(this.frm_cliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtIDCli;
        private System.Windows.Forms.TextBox txtNomeCli;
        private System.Windows.Forms.TextBox txtDataNascCli;
        private System.Windows.Forms.TextBox txtCpfouCnpjCli;
        private System.Windows.Forms.TextBox txtEmailCli;
        private System.Windows.Forms.TextBox txtCEPCli;
        private System.Windows.Forms.TextBox txtTeleCli;
        private System.Windows.Forms.TextBox txtCidadeCli;
        private System.Windows.Forms.ComboBox cmbTipoPessoaCli;
        private System.Windows.Forms.TextBox txtEstadoCli;
        private System.Windows.Forms.TextBox txtRuaouAvenidaCli;
        private System.Windows.Forms.TextBox txtNumeroCli;
        private System.Windows.Forms.TextBox txtBairroCli;
        private System.Windows.Forms.TextBox txtComplementoCli;
        private System.Windows.Forms.Button btnCadastrarCli;
        private System.Windows.Forms.Button btnAlterarCli;
        private System.Windows.Forms.Button btnExcluirCli;
        private System.Windows.Forms.Button btnBuscarCli;
        private System.Windows.Forms.ComboBox cmbResponsavelCliente;
        private System.Windows.Forms.Label label2;
    }
}