﻿namespace sistemaBlessed
{
    partial class frm_ordemServico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtPrevisaoEntregaOS = new System.Windows.Forms.TextBox();
            this.cmbStatusOS = new System.Windows.Forms.ComboBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.txtNumeroOS = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtEmailCli = new System.Windows.Forms.TextBox();
            this.txtTeleCli = new System.Windows.Forms.TextBox();
            this.txtNomeCli = new System.Windows.Forms.TextBox();
            this.txtIDCli = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtDiagTecEquipa = new System.Windows.Forms.TextBox();
            this.txtDefeitoClienteEquipa = new System.Windows.Forms.TextBox();
            this.txtTecResponsavelEquipa = new System.Windows.Forms.TextBox();
            this.txtNumeroSerieEquipa = new System.Windows.Forms.TextBox();
            this.txtSenhaseFornecEquipa = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtModeloEquipa = new System.Windows.Forms.TextBox();
            this.txtMarcaEquipa = new System.Windows.Forms.TextBox();
            this.txtCatEquipa = new System.Windows.Forms.TextBox();
            this.txtNomeEquipa = new System.Windows.Forms.TextBox();
            this.txtIDEquipa = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtValorTotMaoObraOS = new System.Windows.Forms.TextBox();
            this.txtValorTotPecOS = new System.Windows.Forms.TextBox();
            this.txtPecUtilizadasOS = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCadastrarOS = new System.Windows.Forms.Button();
            this.btnExcluirOS = new System.Windows.Forms.Button();
            this.btnAlterarOS = new System.Windows.Forms.Button();
            this.btnImprimirOS = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(788, 69);
            this.label1.TabIndex = 3;
            this.label1.Text = "Cadastro de Ordem de Serviço";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtPrevisaoEntregaOS);
            this.panel1.Controls.Add(this.cmbStatusOS);
            this.panel1.Controls.Add(this.txtDataEntrada);
            this.panel1.Controls.Add(this.txtNumeroOS);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Location = new System.Drawing.Point(33, 155);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(321, 100);
            this.panel1.TabIndex = 4;
            // 
            // txtPrevisaoEntregaOS
            // 
            this.txtPrevisaoEntregaOS.Location = new System.Drawing.Point(152, 70);
            this.txtPrevisaoEntregaOS.Name = "txtPrevisaoEntregaOS";
            this.txtPrevisaoEntregaOS.Size = new System.Drawing.Size(105, 20);
            this.txtPrevisaoEntregaOS.TabIndex = 61;
            // 
            // cmbStatusOS
            // 
            this.cmbStatusOS.FormattingEnabled = true;
            this.cmbStatusOS.Items.AddRange(new object[] {
            "Entregue",
            "Em Andamento",
            "Aguardando Aprovação",
            "Cancelada",
            "Aguardando Peças e Materiais"});
            this.cmbStatusOS.Location = new System.Drawing.Point(9, 70);
            this.cmbStatusOS.Name = "cmbStatusOS";
            this.cmbStatusOS.Size = new System.Drawing.Size(133, 21);
            this.cmbStatusOS.TabIndex = 56;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(152, 27);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(118, 20);
            this.txtDataEntrada.TabIndex = 60;
            // 
            // txtNumeroOS
            // 
            this.txtNumeroOS.Location = new System.Drawing.Point(9, 27);
            this.txtNumeroOS.Name = "txtNumeroOS";
            this.txtNumeroOS.Size = new System.Drawing.Size(133, 20);
            this.txtNumeroOS.TabIndex = 56;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(148, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 20);
            this.label8.TabIndex = 59;
            this.label8.Text = "Previsão de Entrega";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(148, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 20);
            this.label7.TabIndex = 58;
            this.label7.Text = "Data de Entrada";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 57;
            this.label6.Text = "Status";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 20);
            this.label10.TabIndex = 56;
            this.label10.Text = "Número da OS";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtEmailCli);
            this.panel2.Controls.Add(this.txtTeleCli);
            this.panel2.Controls.Add(this.txtNomeCli);
            this.panel2.Controls.Add(this.txtIDCli);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(397, 155);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(434, 100);
            this.panel2.TabIndex = 5;
            // 
            // txtEmailCli
            // 
            this.txtEmailCli.Location = new System.Drawing.Point(193, 68);
            this.txtEmailCli.Name = "txtEmailCli";
            this.txtEmailCli.Size = new System.Drawing.Size(226, 20);
            this.txtEmailCli.TabIndex = 63;
            // 
            // txtTeleCli
            // 
            this.txtTeleCli.Location = new System.Drawing.Point(193, 27);
            this.txtTeleCli.Name = "txtTeleCli";
            this.txtTeleCli.Size = new System.Drawing.Size(118, 20);
            this.txtTeleCli.TabIndex = 64;
            // 
            // txtNomeCli
            // 
            this.txtNomeCli.Location = new System.Drawing.Point(11, 70);
            this.txtNomeCli.Name = "txtNomeCli";
            this.txtNomeCli.Size = new System.Drawing.Size(118, 20);
            this.txtNomeCli.TabIndex = 63;
            // 
            // txtIDCli
            // 
            this.txtIDCli.Location = new System.Drawing.Point(10, 29);
            this.txtIDCli.Name = "txtIDCli";
            this.txtIDCli.Size = new System.Drawing.Size(118, 20);
            this.txtIDCli.TabIndex = 62;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(193, 50);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 20);
            this.label13.TabIndex = 61;
            this.label13.Text = "Email";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(190, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 20);
            this.label12.TabIndex = 58;
            this.label12.Text = "Telefone";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 20);
            this.label11.TabIndex = 60;
            this.label11.Text = "Nome";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 20);
            this.label9.TabIndex = 60;
            this.label9.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 30);
            this.label4.TabIndex = 11;
            this.label4.Text = "Dados da OS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(392, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 30);
            this.label2.TabIndex = 12;
            this.label2.Text = "Dados do Cliente";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtDiagTecEquipa);
            this.panel3.Controls.Add(this.txtDefeitoClienteEquipa);
            this.panel3.Controls.Add(this.txtTecResponsavelEquipa);
            this.panel3.Controls.Add(this.txtNumeroSerieEquipa);
            this.panel3.Controls.Add(this.txtSenhaseFornecEquipa);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.txtModeloEquipa);
            this.panel3.Controls.Add(this.txtMarcaEquipa);
            this.panel3.Controls.Add(this.txtCatEquipa);
            this.panel3.Controls.Add(this.txtNomeEquipa);
            this.panel3.Controls.Add(this.txtIDEquipa);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Location = new System.Drawing.Point(32, 315);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(799, 428);
            this.panel3.TabIndex = 6;
            // 
            // txtDiagTecEquipa
            // 
            this.txtDiagTecEquipa.Location = new System.Drawing.Point(21, 340);
            this.txtDiagTecEquipa.Multiline = true;
            this.txtDiagTecEquipa.Name = "txtDiagTecEquipa";
            this.txtDiagTecEquipa.Size = new System.Drawing.Size(763, 73);
            this.txtDiagTecEquipa.TabIndex = 81;
            // 
            // txtDefeitoClienteEquipa
            // 
            this.txtDefeitoClienteEquipa.Location = new System.Drawing.Point(20, 171);
            this.txtDefeitoClienteEquipa.Multiline = true;
            this.txtDefeitoClienteEquipa.Name = "txtDefeitoClienteEquipa";
            this.txtDefeitoClienteEquipa.Size = new System.Drawing.Size(764, 77);
            this.txtDefeitoClienteEquipa.TabIndex = 80;
            // 
            // txtTecResponsavelEquipa
            // 
            this.txtTecResponsavelEquipa.Location = new System.Drawing.Point(19, 284);
            this.txtTecResponsavelEquipa.Name = "txtTecResponsavelEquipa";
            this.txtTecResponsavelEquipa.Size = new System.Drawing.Size(388, 20);
            this.txtTecResponsavelEquipa.TabIndex = 79;
            // 
            // txtNumeroSerieEquipa
            // 
            this.txtNumeroSerieEquipa.Location = new System.Drawing.Point(599, 116);
            this.txtNumeroSerieEquipa.Name = "txtNumeroSerieEquipa";
            this.txtNumeroSerieEquipa.Size = new System.Drawing.Size(139, 20);
            this.txtNumeroSerieEquipa.TabIndex = 78;
            // 
            // txtSenhaseFornecEquipa
            // 
            this.txtSenhaseFornecEquipa.Location = new System.Drawing.Point(340, 64);
            this.txtSenhaseFornecEquipa.Name = "txtSenhaseFornecEquipa";
            this.txtSenhaseFornecEquipa.Size = new System.Drawing.Size(160, 20);
            this.txtSenhaseFornecEquipa.TabIndex = 77;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(597, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(136, 20);
            this.label18.TabIndex = 76;
            this.label18.Text = "Número de Série";
            // 
            // txtModeloEquipa
            // 
            this.txtModeloEquipa.Location = new System.Drawing.Point(386, 116);
            this.txtModeloEquipa.Name = "txtModeloEquipa";
            this.txtModeloEquipa.Size = new System.Drawing.Size(189, 20);
            this.txtModeloEquipa.TabIndex = 75;
            // 
            // txtMarcaEquipa
            // 
            this.txtMarcaEquipa.Location = new System.Drawing.Point(18, 116);
            this.txtMarcaEquipa.Name = "txtMarcaEquipa";
            this.txtMarcaEquipa.Size = new System.Drawing.Size(170, 20);
            this.txtMarcaEquipa.TabIndex = 74;
            // 
            // txtCatEquipa
            // 
            this.txtCatEquipa.Location = new System.Drawing.Point(207, 116);
            this.txtCatEquipa.Name = "txtCatEquipa";
            this.txtCatEquipa.Size = new System.Drawing.Size(160, 20);
            this.txtCatEquipa.TabIndex = 73;
            // 
            // txtNomeEquipa
            // 
            this.txtNomeEquipa.Location = new System.Drawing.Point(17, 64);
            this.txtNomeEquipa.Name = "txtNomeEquipa";
            this.txtNomeEquipa.Size = new System.Drawing.Size(298, 20);
            this.txtNomeEquipa.TabIndex = 72;
            // 
            // txtIDEquipa
            // 
            this.txtIDEquipa.Location = new System.Drawing.Point(38, 10);
            this.txtIDEquipa.Name = "txtIDEquipa";
            this.txtIDEquipa.Size = new System.Drawing.Size(118, 20);
            this.txtIDEquipa.TabIndex = 65;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(17, 261);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(164, 20);
            this.label24.TabIndex = 71;
            this.label24.Text = "Técnico Responsável";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(17, 317);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(185, 20);
            this.label23.TabIndex = 70;
            this.label23.Text = "Diagnóstico do Técnico";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(17, 148);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(222, 20);
            this.label22.TabIndex = 69;
            this.label22.Text = "Defeito relatado pelo cliente";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(339, 41);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(154, 20);
            this.label21.TabIndex = 68;
            this.label21.Text = "Senha se Fornecida";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(9, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 20);
            this.label19.TabIndex = 66;
            this.label19.Text = "ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(385, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 20);
            this.label17.TabIndex = 64;
            this.label17.Text = "Modelo";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(17, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 20);
            this.label16.TabIndex = 63;
            this.label16.Text = "Marca";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(205, 96);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 20);
            this.label15.TabIndex = 62;
            this.label15.Text = "Categoria";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(14, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(111, 20);
            this.label14.TabIndex = 61;
            this.label14.Text = "Equipamento";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 30);
            this.label3.TabIndex = 13;
            this.label3.Text = "Equipamento";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtValorTotMaoObraOS);
            this.panel4.Controls.Add(this.txtValorTotPecOS);
            this.panel4.Controls.Add(this.txtPecUtilizadasOS);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Location = new System.Drawing.Point(33, 815);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(798, 172);
            this.panel4.TabIndex = 7;
            // 
            // txtValorTotMaoObraOS
            // 
            this.txtValorTotMaoObraOS.Location = new System.Drawing.Point(267, 139);
            this.txtValorTotMaoObraOS.Name = "txtValorTotMaoObraOS";
            this.txtValorTotMaoObraOS.Size = new System.Drawing.Size(105, 20);
            this.txtValorTotMaoObraOS.TabIndex = 83;
            // 
            // txtValorTotPecOS
            // 
            this.txtValorTotPecOS.Location = new System.Drawing.Point(19, 139);
            this.txtValorTotPecOS.Name = "txtValorTotPecOS";
            this.txtValorTotPecOS.Size = new System.Drawing.Size(105, 20);
            this.txtValorTotPecOS.TabIndex = 82;
            // 
            // txtPecUtilizadasOS
            // 
            this.txtPecUtilizadasOS.Location = new System.Drawing.Point(20, 34);
            this.txtPecUtilizadasOS.Multiline = true;
            this.txtPecUtilizadasOS.Name = "txtPecUtilizadasOS";
            this.txtPecUtilizadasOS.Size = new System.Drawing.Size(763, 71);
            this.txtPecUtilizadasOS.TabIndex = 82;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(263, 118);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(250, 20);
            this.label27.TabIndex = 74;
            this.label27.Text = "Valor Total da Mão de Obra (R$)";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(16, 118);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(201, 20);
            this.label26.TabIndex = 73;
            this.label26.Text = "Valor Total das Peças (R$)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft JhengHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(21, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(129, 20);
            this.label25.TabIndex = 72;
            this.label25.Text = "Peças Utilizadas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(30, 776);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 30);
            this.label5.TabIndex = 14;
            this.label5.Text = "Peças e Serviços";
            // 
            // btnCadastrarOS
            // 
            this.btnCadastrarOS.Location = new System.Drawing.Point(466, 1017);
            this.btnCadastrarOS.Name = "btnCadastrarOS";
            this.btnCadastrarOS.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarOS.TabIndex = 54;
            this.btnCadastrarOS.Text = "Cadastrar";
            this.btnCadastrarOS.UseVisualStyleBackColor = true;
            // 
            // btnExcluirOS
            // 
            this.btnExcluirOS.Location = new System.Drawing.Point(756, 1017);
            this.btnExcluirOS.Name = "btnExcluirOS";
            this.btnExcluirOS.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirOS.TabIndex = 53;
            this.btnExcluirOS.Text = "Excluir";
            this.btnExcluirOS.UseVisualStyleBackColor = true;
            this.btnExcluirOS.Click += new System.EventHandler(this.btnExcluirOS_Click);
            // 
            // btnAlterarOS
            // 
            this.btnAlterarOS.Location = new System.Drawing.Point(654, 1017);
            this.btnAlterarOS.Name = "btnAlterarOS";
            this.btnAlterarOS.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarOS.TabIndex = 52;
            this.btnAlterarOS.Text = "Alterar";
            this.btnAlterarOS.UseVisualStyleBackColor = true;
            this.btnAlterarOS.Click += new System.EventHandler(this.btnAlterarOS_Click);
            // 
            // btnImprimirOS
            // 
            this.btnImprimirOS.Location = new System.Drawing.Point(562, 1017);
            this.btnImprimirOS.Name = "btnImprimirOS";
            this.btnImprimirOS.Size = new System.Drawing.Size(75, 23);
            this.btnImprimirOS.TabIndex = 55;
            this.btnImprimirOS.Text = "Imprimir";
            this.btnImprimirOS.UseVisualStyleBackColor = true;
            this.btnImprimirOS.Click += new System.EventHandler(this.btnImprimirOS_Click);
            // 
            // frm_ordemServico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 1061);
            this.Controls.Add(this.btnImprimirOS);
            this.Controls.Add(this.btnCadastrarOS);
            this.Controls.Add(this.btnExcluirOS);
            this.Controls.Add(this.btnAlterarOS);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "frm_ordemServico";
            this.Text = "frm_ordemServico";
            this.Load += new System.EventHandler(this.frm_ordemServico_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCadastrarOS;
        private System.Windows.Forms.Button btnExcluirOS;
        private System.Windows.Forms.Button btnAlterarOS;
        private System.Windows.Forms.Button btnImprimirOS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtPrevisaoEntregaOS;
        private System.Windows.Forms.ComboBox cmbStatusOS;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.TextBox txtNumeroOS;
        private System.Windows.Forms.TextBox txtNomeCli;
        private System.Windows.Forms.TextBox txtEmailCli;
        private System.Windows.Forms.TextBox txtTeleCli;
        private System.Windows.Forms.TextBox txtIDEquipa;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtModeloEquipa;
        private System.Windows.Forms.TextBox txtMarcaEquipa;
        private System.Windows.Forms.TextBox txtCatEquipa;
        private System.Windows.Forms.TextBox txtNomeEquipa;
        private System.Windows.Forms.TextBox txtDiagTecEquipa;
        private System.Windows.Forms.TextBox txtDefeitoClienteEquipa;
        private System.Windows.Forms.TextBox txtTecResponsavelEquipa;
        private System.Windows.Forms.TextBox txtNumeroSerieEquipa;
        private System.Windows.Forms.TextBox txtSenhaseFornecEquipa;
        private System.Windows.Forms.TextBox txtPecUtilizadasOS;
        private System.Windows.Forms.TextBox txtValorTotMaoObraOS;
        private System.Windows.Forms.TextBox txtValorTotPecOS;
        private System.Windows.Forms.TextBox txtIDCli;
    }
}