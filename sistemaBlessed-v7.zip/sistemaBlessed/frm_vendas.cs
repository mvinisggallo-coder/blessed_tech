﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_vendas : Form
    {
        public frm_vendas()
        {
            InitializeComponent();
        }

        private void frm_vendas_Load(object sender, EventArgs e)
        {
            txtIdVen.ReadOnly = true; // Impede que o usuário altere o ID da venda
        }
        private void LimparCampos()
        {
            txtIdVen.Clear();
            txtNomeProd.Clear();
            txtFormaPagVen.Clear();
            txtDataVen.Clear();
            txtIdProd.Clear();
            txtNomeProd.Clear();
            txtQtdItemVenda.Clear();
            txtValorTotItemVenda.Clear();
            txtDescoItemVenda.Clear();
            txtValoraPagItemVenda.Clear();
            txtValorPagoItemVenda.Clear();
            txtTrocoItemVenda.Clear();
            txtNomeProd.Focus();
        }



        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnAlterarVen_Click(object sender, EventArgs e)
        {

        }

        private void btnExcluirVen_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrarVen_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();

                    }


























                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar venda: " + ex.Message);
                }

            }
        }
    }
}




