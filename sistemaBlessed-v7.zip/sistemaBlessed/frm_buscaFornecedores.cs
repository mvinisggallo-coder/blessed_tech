﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_buscaFornecedores : Form
    {
        public frm_buscaFornecedores()
        {
            InitializeComponent();
        }

        private void carregarFornecedor()
        {
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"SELECT
                    IDFornecedor AS ID,
                    NomeFornecdor,
                    CNPJouCPF,
                    Telefone,
                    StatusFornecedor,
                    Email,
                    
                        FROM Fornecedores
                        ORDER BY NomeFornecdor";

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();

                    adapter.Fill(tabela);

                    dgvFornec.DataSource = tabela;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar fornecedores:\n" + ex.Message);
            }







        }


        private void btnBuscarFornec_Click(object sender, EventArgs e)
        {
            


            }
        }

        private void btnCarregarImagemFornec_Click(object sender, EventArgs e)
        {

        }
    }
}
