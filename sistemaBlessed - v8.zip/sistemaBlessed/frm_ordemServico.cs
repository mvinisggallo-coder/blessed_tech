﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_ordemServico : Form
    {
        public frm_ordemServico()
        {
            InitializeComponent();
        }

        private void carregarCliente()
        {
            try

            {

                using (SqlConnection conexao =

                    conexao_banco.CriarConexao())

                {

                    conexao.Open();

                    string sql = @"SELECT

                            IDCliente,

                            NomeCliente

                           FROM Clientes

                           ORDER BY NomeCliente";

                    SqlDataAdapter adaptador =

                        new SqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();

                    adaptador.Fill(tabela);

                    // Exibe o nome do cliente

                    cmbResponsavelEquipa.DisplayMember = "NomeCliente";

                    // Armazena o ID do cliente

                    cmbResponsavelEquipa.ValueMember = "IDCliente";

                    // Carrega os dados

                    cmbResponsavelEquipa.DataSource = tabela;

                    // Inicia sem seleção

                    cmbResponsavelEquipa.SelectedIndex = -1;

                }

            }

            catch (Exception ex)

            {

                MessageBox.Show(

                    "Erro ao carregar clientes: " + ex.Message);

            }

        }
        
        private void BuscarCPF()
        {
            try
            {
                // Verifica se existe um cliente selecionado
                if (cmbResponsavelEquipa.SelectedIndex == -1)
                    return;

                // Obtém o ID do cliente selecionado
                int idCliente = Convert.ToInt32(
                    cmbResponsavelEquipa.SelectedValue);

                using (SqlConnection conexao =
                    conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"
                SELECT CPF
                FROM Clientes
                WHERE IDCliente = @IDCliente";

                    using (SqlCommand comando =
                        new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue(
                            "@IDCliente", idCliente);

                        object resultado = comando.ExecuteScalar();

                        if (resultado != null &&
                            resultado != DBNull.Value)
                        {
                            txtCPF.Text = resultado.ToString();
                        }
                        else
                        {
                            txtCPF.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao buscar CPF: " + ex.Message);
            }
        }



























        












































        private void frm_ordemServico_Load(object sender, EventArgs e)
        {
            txtNumeroOS.ReadOnly = true;

            cmbStatusOS.Items.Clear();
            cmbStatusOS.Items.Add("Entregue");
            cmbStatusOS.Items.Add("Em Andamento");
            cmbStatusOS.Items.Add("Aguardando Aprovação");
            cmbStatusOS.Items.Add("Cancelada");
            cmbStatusOS.Items.Add("Aguardando Peças e Materiais");



            // Impede que o usuário digite outras opções
            cmbStatusOS.DropDownStyle = ComboBoxStyle.DropDownList;

            // Seleciona Ativo como padrão
            cmbStatusOS.SelectedIndex = 0;


            // Seleciona Ativo como padrão
            cmbStatusOS.SelectedIndex = 0;



            cmbResponsavelEquipa.DropDownStyle = ComboBoxStyle.DropDownList;
            limparCampos();
            carregarCliente();

        }

        private void limparCampos()
        {
            txtNumeroOS.Clear();
            txtDataEntrada.Clear();
            txtPrevisaoEntregaOS.Clear();
            txtTeleCli.Clear();           
            txtEmailCli.Clear();
            txtIDEquipa.Clear();
            txtNomeEquipa.Clear();
            txtSenhaseFornecEquipa.Clear();
            txtMarcaEquipa.Clear();
            txtCatEquipa.Clear();
            txtModeloEquipa.Clear();
            txtNumeroSerieEquipa.Clear();
            txtDefeitoClienteEquipa.Clear();
            txtTecResponsavelEquipa.Clear();
            txtDiagTecEquipa.Clear();
            txtPecUtilizadasOS.Clear();
            txtValorTotPecOS.Clear();
            txtValorTotMaoObraOS.Clear();

            cmbStatusOS.SelectedIndex = 0;
            cmbResponsavelEquipa.SelectedIndex = -1;

            txtDataEntrada.Focus();
        }





        private void btnImprimirOS_Click(object sender, EventArgs e)
        {

        }

        private void btnAlterarOS_Click(object sender, EventArgs e)
        {

        }

        private void btnExcluirOS_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrarOS_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    using (SqlConnection conexao = conexao_banco.CriarConexao())
                    {
                        conexao.Open();
                        string sql = @"
                            INSERT INTO OrdensServico (
                                IDOS,
                                StatusOS,
                                DataEntradaOS,
                                PrevisaoEntregaOS,
                                IDCliente,
                                IDEquipa,
                                DefeitoRelatCli,
                                DiagTecnico,
                                TecResponsavel,
                                PecasUtilizadas,
                                ValorTotPecas,
                                ValorTotMaoObra,
                            ) VALUES (
                                @IDOS,
                                @StatusOS,
                                @DataEntradaOS,
                                @PrevisaoEntregaOS,
                                @IDCliente,
                                @IDEquipa,
                                @DefeitoRelatCli,
                                @DiagTecnico,
                                @TecResponsavel,
                                @PecasUtilizadas,
                                @ValorTotPecas,
                                @ValorTotMaoObra
                            )";
                        using (SqlCommand comando = new SqlCommand(sql, conexao))
                        {
                            // Adicione os parâmetros aqui, por exemplo:
                            comando.Parameters.AddWithValue("@IDOS", txtNumeroOS.Text);
                            comando.Parameters.AddWithValue("@DataEntradaOS", txtDataEntrada.Text);
                            comando.Parameters.AddWithValue("@PrevisaoEntregaOS", txtPrevisaoEntregaOS.Text);
                            comando.Parameters.AddWithValue("@IDCliente", cmbResponsavelEquipa.SelectedValue);
                            comando.Parameters.AddWithValue("@IDEquipa", txtIDEquipa.Text);
                            comando.Parameters.AddWithValue("@DefeitoRelatCli", txtDefeitoClienteEquipa.Text);
                            comando.Parameters.AddWithValue("@DiagTecnico", txtDiagTecEquipa.Text);
                            comando.Parameters.AddWithValue("@TecResponsavel", txtTecResponsavelEquipa.Text);
                            comando.Parameters.AddWithValue("@PecasUtilizadas", txtPecUtilizadasOS.Text);
                            comando.Parameters.AddWithValue("@ValorTotPecas", txtValorTotPecOS.Text);
                            comando.Parameters.AddWithValue("@ValorTotMaoObra", txtValorTotMaoObraOS.Text);

                            // ComboBox - Status
                            comando.Parameters.AddWithValue(
                                "@StatusGerente", cmbStatusOS.SelectedItem.ToString());

                            int linhasAfetadas = comando.ExecuteNonQuery();

                            if (linhasAfetadas > 0)
                            {
                                MessageBox.Show("Ordem de Serviço cadastrada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                limparCampos();

                            }
                            else
                            {
                                MessageBox.Show("Falha ao cadastrar a Ordem de Serviço.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);


                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao cadastrar a Ordem de Serviço: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cmbResponsavelEquipa_SelectedIndexChanged(object sender, EventArgs e)
        {
            BuscarCPF();
            if (cmbResponsavelEquipa.SelectedIndex == -1 ||
        cmbResponsavelEquipa.SelectedValue == null)
            {
                txtCPF.Clear();
                return;
            }
        }
        

        private void btnBuscarEquipa_Click(object sender, EventArgs e)
        {
            try
            {













                if (txtIDEquipa.Text == "")
                {
                    MessageBox.Show("Por favor, insira o ID do equipamento para buscar.");
                    txtIDEquipa.Focus();
                    return;
                }
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();
                    string sql = @"SELECT * FROM EquipamentosOS WHERE NomeEquipamento = @NomeEquipamento";
                    using (SqlCommand comando = new SqlCommand(sql, conexao))
                    {
                        comando.Parameters.AddWithValue("@NomeEquipamento", txtNomeEquipa.Text);
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.Read())
                            {

                                cmbResponsavelEquipa.SelectedValue = reader["IDCliente"];
                                txtCatEquipa.Text = reader["CatEquipa"].ToString();
                                txtNumeroSerieEquipa.Text = reader["NumeroSerieEquipa"].ToString();
                                txtMarcaEquipa.Text = reader["MarcaEquipa"].ToString();
                                txtModeloEquipa.Text = reader["ModeloEquipa"].ToString();
                                txtSenhaseFornecEquipa.Text = reader["SenhaSeFornecEquipa"].ToString();
                            }

                            else
                            {
                                MessageBox.Show("Equipamento não encontrado.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar equipamento:\n" + ex.Message);
            }

        }
    }
}

























                





























































