﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_buscaOrdensServico : Form
    {
        public frm_buscaOrdensServico()
        {
            InitializeComponent();
        }
        private void carregarOrdensServico()
        {
            
            }
























        private void btnBuscarOS_Click(object sender, EventArgs e)
        {

        }

        private void btnCarregarImagemEquip_Click(object sender, EventArgs e)
        {

        }
    }
}
