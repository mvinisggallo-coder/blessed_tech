﻿namespace sistemaBlessed
{
    partial class frm_buscaFornecedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtIdFor = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pic_imagemFornec = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dgvFornec = new System.Windows.Forms.DataGridView();
            this.btnBuscarFornec = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemFornec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFornec)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(762, 69);
            this.label1.TabIndex = 3;
            this.label1.Text = "Busca de Fornecedores Ativos";
            // 
            // txtIdFor
            // 
            this.txtIdFor.Location = new System.Drawing.Point(55, 108);
            this.txtIdFor.Name = "txtIdFor";
            this.txtIdFor.Size = new System.Drawing.Size(100, 20);
            this.txtIdFor.TabIndex = 31;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(27, 106);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 30;
            this.label10.Text = "ID";
            // 
            // pic_imagemFornec
            // 
            this.pic_imagemFornec.Location = new System.Drawing.Point(692, 161);
            this.pic_imagemFornec.Name = "pic_imagemFornec";
            this.pic_imagemFornec.Size = new System.Drawing.Size(241, 250);
            this.pic_imagemFornec.TabIndex = 49;
            this.pic_imagemFornec.TabStop = false;
            this.pic_imagemFornec.Click += new System.EventHandler(this.pic_imagemFornec_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label18.Location = new System.Drawing.Point(701, 123);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(221, 24);
            this.label18.TabIndex = 48;
            this.label18.Text = "Imagem do Fornecedor";
            // 
            // dgvFornec
            // 
            this.dgvFornec.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFornec.Location = new System.Drawing.Point(24, 198);
            this.dgvFornec.Name = "dgvFornec";
            this.dgvFornec.Size = new System.Drawing.Size(595, 208);
            this.dgvFornec.TabIndex = 51;
            // 
            // btnBuscarFornec
            // 
            this.btnBuscarFornec.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 14.25F, System.Drawing.FontStyle.Italic);
            this.btnBuscarFornec.Location = new System.Drawing.Point(190, 99);
            this.btnBuscarFornec.Name = "btnBuscarFornec";
            this.btnBuscarFornec.Size = new System.Drawing.Size(96, 32);
            this.btnBuscarFornec.TabIndex = 52;
            this.btnBuscarFornec.Text = "Buscar";
            this.btnBuscarFornec.UseVisualStyleBackColor = true;
            this.btnBuscarFornec.Click += new System.EventHandler(this.btnBuscarFornec_Click);
            // 
            // frm_buscaFornecedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 477);
            this.Controls.Add(this.btnBuscarFornec);
            this.Controls.Add(this.dgvFornec);
            this.Controls.Add(this.pic_imagemFornec);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtIdFor);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Name = "frm_buscaFornecedores";
            this.Text = "frm_buscaFornecedores";
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagemFornec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFornec)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIdFor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pic_imagemFornec;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dgvFornec;
        private System.Windows.Forms.Button btnBuscarFornec;
    }
}