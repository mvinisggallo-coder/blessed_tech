﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemaBlessed
{
    public partial class frm_buscaFornecedores : Form
    {
        public frm_buscaFornecedores()
        {
            InitializeComponent();
        }

        private void carregarFornecedor()
        {
            try
            {
                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"SELECT
                    IDFornecedor AS ID,
                    NomeFornecdor,
                    CNPJouCPF,
                    Telefone,
                    StatusFornecedor,
                    Email,
                    Imagem,
                    
                        FROM Fornecedores
                        ORDER BY NomeFornecdor";

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao);

                    DataTable tabela = new DataTable();

                    adapter.Fill(tabela);

                    dgvFornec.DataSource = tabela;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar fornecedores:\n" + ex.Message);
            }







        }


        private void btnBuscarFornec_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtIdFor.Text, out int id))
                {
                    MessageBox.Show("Digite o ID para buscar o fornecedor.");
                    return;
                }

                using (SqlConnection conexao = conexao_banco.CriarConexao())
                {
                    conexao.Open();

                    string sql = @"
                        SELECT
                            NomeFornecdor,
                            CNPJouCPF,
                            Telefone,
                            Email,
                            StatusFornecedor,
                            Imagem
                        FROM Fornecedores
                        WHERE IDFornecedor = @IDFornecedor";

                    SqlDataAdapter adapter = new SqlDataAdapter(sql, conexao);

                    adapter.SelectCommand.Parameters.AddWithValue(
                        "@IDFornecedor", id);

                    DataTable tabela = new DataTable();

                    adapter.Fill(tabela);

                    if (tabela.Rows.Count == 0)
                    {
                        
                        dgvFornec.DataSource = null;
                        pic_imagemFornec.Image = null;

                        MessageBox.Show("Fornecedor não encontrado.");
                        return;
                    }

                    // Exibe o nome do fornecedor
                    

                    // Exibe CNPJ, telefone e status no DataGridView
                    DataTable dados = tabela.DefaultView.ToTable(
                        false, "NomeFornecdor", "CNPJouCPF", "Telefone","Email","StatusFornecedor");

                    dgvFornec.DataSource = dados;

                    // Carrega a imagem armazenada no SQL Server
                    pic_imagemFornec.Image = null;
                    pic_imagemFornec.SizeMode =
                        PictureBoxSizeMode.Zoom;

                    if (tabela.Rows[0]["Imagem"] != DBNull.Value)
                    {
                        byte[] bytes =
                            (byte[])tabela.Rows[0]["Imagem"];

                        using (MemoryStream memoria = new MemoryStream(bytes))
                        using (Image imagem = Image.FromStream(memoria))
                        {
                            pic_imagemFornec.Image = new Bitmap(imagem);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar fornecedor:\n" + ex.Message);
            }
        }

        private void pic_imagemFornec_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Image imagemAnterior = pic_imagemFornec.Image;
                    pic_imagemFornec.Image = Image.FromFile(openFileDialog.FileName);
                    imagemAnterior?.Dispose();

                }
    }
}


        }

       
    }



        
