﻿namespace sistemaBlessed
{
    partial class frm_vendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtQtdItemVenda = new System.Windows.Forms.TextBox();
            this.txtIdVen = new System.Windows.Forms.TextBox();
            this.txtIdProd = new System.Windows.Forms.TextBox();
            this.txtDataVen = new System.Windows.Forms.TextBox();
            this.txtNomeProd = new System.Windows.Forms.TextBox();
            this.btnExcluirVen = new System.Windows.Forms.Button();
            this.btnAlterarVen = new System.Windows.Forms.Button();
            this.btnCadastrarVen = new System.Windows.Forms.Button();
            this.btnAdicProd = new System.Windows.Forms.Button();
            this.btnExcluProd = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtValorTotItemVenda = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.cmbCli = new System.Windows.Forms.ComboBox();
            this.txtFormaPagVen = new System.Windows.Forms.TextBox();
            this.dgvItemVenda = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemVenda)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei Light", 40F);
            this.label1.Location = new System.Drawing.Point(52, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 69);
            this.label1.TabIndex = 2;
            this.label1.Text = "Vendas";
            // 
            // txtQtdItemVenda
            // 
            this.txtQtdItemVenda.Location = new System.Drawing.Point(452, 144);
            this.txtQtdItemVenda.Name = "txtQtdItemVenda";
            this.txtQtdItemVenda.Size = new System.Drawing.Size(70, 20);
            this.txtQtdItemVenda.TabIndex = 7;
            // 
            // txtIdVen
            // 
            this.txtIdVen.Location = new System.Drawing.Point(93, 88);
            this.txtIdVen.Name = "txtIdVen";
            this.txtIdVen.Size = new System.Drawing.Size(100, 20);
            this.txtIdVen.TabIndex = 6;
            // 
            // txtIdProd
            // 
            this.txtIdProd.Location = new System.Drawing.Point(138, 74);
            this.txtIdProd.Name = "txtIdProd";
            this.txtIdProd.Size = new System.Drawing.Size(100, 20);
            this.txtIdProd.TabIndex = 9;
            // 
            // txtDataVen
            // 
            this.txtDataVen.Location = new System.Drawing.Point(289, 223);
            this.txtDataVen.Name = "txtDataVen";
            this.txtDataVen.Size = new System.Drawing.Size(100, 20);
            this.txtDataVen.TabIndex = 12;
            // 
            // txtNomeProd
            // 
            this.txtNomeProd.Location = new System.Drawing.Point(36, 144);
            this.txtNomeProd.Name = "txtNomeProd";
            this.txtNomeProd.Size = new System.Drawing.Size(353, 20);
            this.txtNomeProd.TabIndex = 15;
            // 
            // btnExcluirVen
            // 
            this.btnExcluirVen.Location = new System.Drawing.Point(948, 729);
            this.btnExcluirVen.Name = "btnExcluirVen";
            this.btnExcluirVen.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirVen.TabIndex = 36;
            this.btnExcluirVen.Text = "Excluir";
            this.btnExcluirVen.UseVisualStyleBackColor = true;
            // 
            // btnAlterarVen
            // 
            this.btnAlterarVen.Location = new System.Drawing.Point(853, 729);
            this.btnAlterarVen.Name = "btnAlterarVen";
            this.btnAlterarVen.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarVen.TabIndex = 35;
            this.btnAlterarVen.Text = "Alterar";
            this.btnAlterarVen.UseVisualStyleBackColor = true;
            // 
            // btnCadastrarVen
            // 
            this.btnCadastrarVen.Location = new System.Drawing.Point(755, 729);
            this.btnCadastrarVen.Name = "btnCadastrarVen";
            this.btnCadastrarVen.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrarVen.TabIndex = 34;
            this.btnCadastrarVen.Text = "Cadastrar";
            this.btnCadastrarVen.UseVisualStyleBackColor = true;
            // 
            // btnAdicProd
            // 
            this.btnAdicProd.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicProd.Location = new System.Drawing.Point(332, 184);
            this.btnAdicProd.Name = "btnAdicProd";
            this.btnAdicProd.Size = new System.Drawing.Size(134, 38);
            this.btnAdicProd.TabIndex = 37;
            this.btnAdicProd.Text = "Adicionar (+)";
            this.btnAdicProd.UseVisualStyleBackColor = true;
            // 
            // btnExcluProd
            // 
            this.btnExcluProd.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluProd.Location = new System.Drawing.Point(483, 184);
            this.btnExcluProd.Name = "btnExcluProd";
            this.btnExcluProd.Size = new System.Drawing.Size(100, 37);
            this.btnExcluProd.TabIndex = 38;
            this.btnExcluProd.Text = "Excluir (-)";
            this.btnExcluProd.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label10.Location = new System.Drawing.Point(64, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 24);
            this.label10.TabIndex = 40;
            this.label10.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label2.Location = new System.Drawing.Point(65, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 24);
            this.label2.TabIndex = 41;
            this.label2.Text = "Cliente";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label3.Location = new System.Drawing.Point(285, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 24);
            this.label3.TabIndex = 42;
            this.label3.Text = "Data";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label4.Location = new System.Drawing.Point(66, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 24);
            this.label4.TabIndex = 43;
            this.label4.Text = "Forma de Pagamento";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvItemVenda);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.txtValorTotItemVenda);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtNomeProd);
            this.panel1.Controls.Add(this.txtQtdItemVenda);
            this.panel1.Controls.Add(this.txtIdProd);
            this.panel1.Controls.Add(this.btnExcluProd);
            this.panel1.Controls.Add(this.btnAdicProd);
            this.panel1.Location = new System.Drawing.Point(68, 266);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(955, 426);
            this.panel1.TabIndex = 44;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft JhengHei Light", 20.75F, System.Drawing.FontStyle.Italic);
            this.label5.Location = new System.Drawing.Point(373, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 35);
            this.label5.TabIndex = 45;
            this.label5.Text = "Itens de Venda";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label7.Location = new System.Drawing.Point(35, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 24);
            this.label7.TabIndex = 46;
            this.label7.Text = "ID Produto";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label8.Location = new System.Drawing.Point(35, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 24);
            this.label8.TabIndex = 45;
            this.label8.Text = "Produto";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label11.Location = new System.Drawing.Point(430, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 24);
            this.label11.TabIndex = 47;
            this.label11.Text = "Quantidade";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label12.Location = new System.Drawing.Point(661, 239);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 24);
            this.label12.TabIndex = 45;
            this.label12.Text = "Valor Total (R$)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label13.Location = new System.Drawing.Point(663, 338);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(148, 24);
            this.label13.TabIndex = 46;
            this.label13.Text = "Valor pago (R$)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label14.Location = new System.Drawing.Point(661, 271);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(136, 24);
            this.label14.TabIndex = 47;
            this.label14.Text = "Desconto (R$)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label15.Location = new System.Drawing.Point(663, 371);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(101, 24);
            this.label15.TabIndex = 48;
            this.label15.Text = "Troco (R$)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft JhengHei", 14.25F);
            this.label16.Location = new System.Drawing.Point(663, 304);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(167, 24);
            this.label16.TabIndex = 49;
            this.label16.Text = "Valor a Pagar (R$)";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(833, 275);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(73, 20);
            this.textBox3.TabIndex = 49;
            // 
            // txtValorTotItemVenda
            // 
            this.txtValorTotItemVenda.Location = new System.Drawing.Point(833, 239);
            this.txtValorTotItemVenda.Name = "txtValorTotItemVenda";
            this.txtValorTotItemVenda.Size = new System.Drawing.Size(73, 20);
            this.txtValorTotItemVenda.TabIndex = 50;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(833, 308);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(73, 20);
            this.textBox6.TabIndex = 51;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(833, 343);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(73, 20);
            this.textBox7.TabIndex = 52;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(833, 375);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(73, 20);
            this.textBox8.TabIndex = 53;
            // 
            // cmbCli
            // 
            this.cmbCli.FormattingEnabled = true;
            this.cmbCli.Location = new System.Drawing.Point(69, 160);
            this.cmbCli.Name = "cmbCli";
            this.cmbCli.Size = new System.Drawing.Size(121, 21);
            this.cmbCli.TabIndex = 45;
            // 
            // txtFormaPagVen
            // 
            this.txtFormaPagVen.Location = new System.Drawing.Point(66, 223);
            this.txtFormaPagVen.Name = "txtFormaPagVen";
            this.txtFormaPagVen.Size = new System.Drawing.Size(195, 20);
            this.txtFormaPagVen.TabIndex = 4;
            // 
            // dgvItemVenda
            // 
            this.dgvItemVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItemVenda.Location = new System.Drawing.Point(39, 245);
            this.dgvItemVenda.Name = "dgvItemVenda";
            this.dgvItemVenda.Size = new System.Drawing.Size(587, 150);
            this.dgvItemVenda.TabIndex = 46;
            // 
            // frm_vendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1071, 786);
            this.Controls.Add(this.cmbCli);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnExcluirVen);
            this.Controls.Add(this.btnAlterarVen);
            this.Controls.Add(this.btnCadastrarVen);
            this.Controls.Add(this.txtDataVen);
            this.Controls.Add(this.txtIdVen);
            this.Controls.Add(this.txtFormaPagVen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "frm_vendas";
            this.Text = "frm_vendas";
            this.Load += new System.EventHandler(this.frm_vendas_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemVenda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQtdItemVenda;
        private System.Windows.Forms.TextBox txtIdVen;
        private System.Windows.Forms.TextBox txtIdProd;
        private System.Windows.Forms.TextBox txtDataVen;
        private System.Windows.Forms.TextBox txtNomeProd;
        private System.Windows.Forms.Button btnExcluirVen;
        private System.Windows.Forms.Button btnAlterarVen;
        private System.Windows.Forms.Button btnCadastrarVen;
        private System.Windows.Forms.Button btnAdicProd;
        private System.Windows.Forms.Button btnExcluProd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtValorTotItemVenda;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbCli;
        private System.Windows.Forms.TextBox txtFormaPagVen;
        private System.Windows.Forms.DataGridView dgvItemVenda;
    }
}